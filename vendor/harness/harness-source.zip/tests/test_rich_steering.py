"""Structured insertion reaches the model and checkpoint without replaying tools."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest
from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from tests.test_steering import ToolModel, config

from octop_harness.protocols.langgraph import LangGraphProtocol
from octop_harness.steering import LiveSteeringMiddleware, StreamSteering


@pytest.mark.asyncio
@pytest.mark.parametrize("boundary", ["before", "model", "tool"])
@pytest.mark.parametrize("image", [False, True])
async def test_verified_message_reaches_model_and_history_once(boundary: str, image: bool) -> None:
    control = StreamSteering()
    model_started, tool_started, release = asyncio.Event(), asyncio.Event(), asyncio.Event()
    effects: list[str] = []
    seen: list[HumanMessage] = []
    attachments = [
        {
            "filename": "补充.png" if image else "补充.txt",
            "workspace_path": "inbound/qa",
            "resource_id": "res_qa",
            "version": "a" * 64,
        }
    ]
    content: Any = [{"type": "text", "text": "已验证的附件提示"}]
    if image:
        content.append({"type": "image_url", "image_url": {"url": "workspace://inbound/qa.png"}})
    submitted = HumanMessage(
        content=content, additional_kwargs={"octop_inbound_attachments": attachments}, id="caller-id"
    )

    @tool
    async def save_once() -> str:
        """Finish one synthetic side effect."""
        effects.append("saved")
        tool_started.set()
        if boundary == "tool":
            await release.wait()
        return "saved"

    class Capture(AgentMiddleware[Any, Any]):
        first = True

        async def awrap_model_call(self, request: Any, handler: Any) -> Any:
            if self.first and boundary == "model":
                self.first = False
                model_started.set()
                await asyncio.Event().wait()
            seen.extend(m for m in request.messages if isinstance(m, HumanMessage) and m.id == "steer:media")
            return await handler(request)

    graph = create_agent(
        ToolModel(
            responses=[
                AIMessage(content="", tool_calls=[{"name": "save_once", "args": {}, "id": "effect"}]),
                AIMessage(content="已收到附件"),
            ]
        ),
        tools=[save_once],
        middleware=[LiveSteeringMiddleware({"test-thread": control}), Capture()],
        checkpointer=InMemorySaver(),
    )

    async def consume() -> list[dict[str, Any]]:
        return [
            chunk
            async for chunk in LangGraphProtocol(graph=graph).stream(
                [HumanMessage(content="original", id="original")], config(control)
            )
        ]

    if boundary == "before":
        assert control.request("media", "", message=submitted) == "accepted"
    task = asyncio.create_task(consume())
    if boundary != "before":
        await asyncio.wait_for((model_started if boundary == "model" else tool_started).wait(), 10)
        assert control.request("media", "", message=submitted) == "accepted"
        release.set()
    chunks = await asyncio.wait_for(task, 10)
    state = await graph.aget_state(config(control))
    inserted = [m for m in state.values["messages"] if m.id == "steer:media"]
    assert len(inserted) == 1
    assert inserted[0].content == submitted.content
    assert inserted[0].additional_kwargs == submitted.additional_kwargs
    assert seen and all(m.content == submitted.content for m in seen)
    assert effects == ["saved"]
    user_events = [chunk for chunk in chunks if chunk.get("type") == "user"]
    assert len(user_events) == 1
    assert user_events[0]["content"] == ""
    assert user_events[0]["inbound_attachments"] == attachments
    assert "workspace://" not in str(user_events)
    assert control.request("media", "", message=submitted) == "applied"


def test_message_identity_is_immutable_and_covers_content_metadata_and_mode() -> None:
    control = StreamSteering()
    original = HumanMessage(
        content=[{"type": "text", "text": "附件"}],
        additional_kwargs={"octop_inbound_attachments": [{"version": "one"}]},
    )
    assert control.request("media", "补充", message=original) == "accepted"
    same = original.model_copy(deep=True)
    original.additional_kwargs["octop_inbound_attachments"][0]["version"] = "changed"
    assert control.request("media", "补充", message=same) == "accepted"
    assert control.request("media", "补充", message=original) == "conflict"
    assert control.request("media", "另一个文字", message=same) == "conflict"
    assert control.request("media", "补充", message=same, cancel_tools=True) == "conflict"
    assert control.pending is not None and control.pending.message is not None
    assert control.pending.message.id == "steer:media"
    assert control.pending.message.content == same.content
    assert control.pending.message.additional_kwargs == same.additional_kwargs


@pytest.mark.asyncio
async def test_multiple_supplements_apply_in_order_without_repeating_admitted_tool() -> None:
    control = StreamSteering()
    started, release = asyncio.Event(), asyncio.Event()
    effects = []

    @tool
    async def work_once() -> str:
        """Finish a single already admitted operation."""
        effects.append("one")
        started.set()
        await release.wait()
        return "done"

    graph = create_agent(
        ToolModel(
            responses=[
                AIMessage(content="", tool_calls=[{"name": "work_once", "args": {}, "id": "work"}]),
                AIMessage(content="继续"),
            ]
        ),
        tools=[work_once],
        middleware=[LiveSteeringMiddleware({"test-thread": control})],
        checkpointer=InMemorySaver(),
    )

    async def consume() -> list[dict[str, Any]]:
        return [
            chunk
            async for chunk in LangGraphProtocol(graph=graph).stream(
                [HumanMessage(content="original")], config(control)
            )
        ]

    task = asyncio.create_task(consume())
    await asyncio.wait_for(started.wait(), 10)
    for number in range(3):
        assert control.request(f"supplement-{number}", f"补充 {number}", queue_if_busy=True) == "accepted"
    release.set()
    chunks = await asyncio.wait_for(task, 10)
    history = await graph.aget_state(config(control))
    assert [m.content for m in history.values["messages"] if m.type == "human"] == [
        "original",
        "补充 0",
        "补充 1",
        "补充 2",
    ]
    assert [c["command_id"] for c in chunks if c.get("type") == "user"] == [f"supplement-{i}" for i in range(3)]
    assert effects == ["one"]


def test_opted_in_buffer_is_bounded_and_duplicate_does_not_consume_capacity() -> None:
    control = StreamSteering()
    for i in range(10):
        assert control.request(str(i), str(i), queue_if_busy=True) == "accepted"
        assert control.request(str(i), str(i), queue_if_busy=True) == "accepted"
    assert control.request("overflow", "overflow", queue_if_busy=True) == "busy"
