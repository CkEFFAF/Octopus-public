from __future__ import annotations

import asyncio
import json
from typing import Any
from uuid import UUID, uuid4

import pytest
from deepagents import create_deep_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from langgraph.types import Command

from octop_harness.middleware.native_task import NativeTaskMiddleware
from octop_harness.observability import RunEventCallback


class Model(FakeMessagesListChatModel):
    def bind_tools(self, tools: Any, **kwargs: Any) -> Any:
        task = next((item for item in tools if getattr(item, "name", None) == "task"), None)
        if task is not None:
            schema = task.args_schema.model_json_schema()
            assert "task_id" in schema["properties"]
            assert "attempt" in schema["properties"]
        return self


@pytest.mark.asyncio
async def test_real_parallel_same_subagent_keeps_jobs_and_public_replies_separate() -> None:
    started: set[str] = set()
    both = asyncio.Event()

    @tool
    async def start_job(label: str) -> str:
        """Start a disposable test job."""
        started.add(label)
        if len(started) == 2:
            both.set()
        await asyncio.wait_for(both.wait(), timeout=5)
        return json.dumps(
            {
                "job_id": f"job-{label}",
                "context_id": f"ctx-{label}",
                "token": "private-job-token",
                "messages": [{"role": "system", "content": "private-job-system"}],
            }
        )

    async def child(state: dict[str, Any]) -> dict[str, Any]:
        label = state["messages"][-1].content
        await start_job.ainvoke({"label": label})
        return {
            "messages": [
                HumanMessage(label),
                AIMessage(
                    content=[
                        {"type": "reasoning", "reasoning": "private-reasoning"},
                        {"type": "text", "text": f"reply-{label}"},
                    ]
                ),
            ]
        }

    events: list[dict[str, Any]] = []
    graph = create_deep_agent(
        model=Model(
            responses=[
                AIMessage(
                    "",
                    tool_calls=[
                        {
                            "id": f"call-{label}",
                            "name": "task",
                            "args": {
                                "description": label,
                                "subagent_type": "worker",
                                "task_id": label,
                                "attempt": "retry-label",
                            },
                        }
                        for label in ("B", "C")
                    ],
                ),
                AIMessage("done"),
            ]
        ),
        middleware=[NativeTaskMiddleware()],
        subagents=[{"name": "worker", "description": "Disposable worker", "runnable": RunnableLambda(child)}],
    )
    await graph.ainvoke(
        {"messages": [HumanMessage("Run both")]},
        config={
            "callbacks": [RunEventCallback(events.append)],
            "configurable": {"octop_task_run_id": "root-34", "thread_id": "test-thread", "user": "test-owner"},
        },
    )
    tasks = [event for event in events if event["kind"] == "dispatch" and event["status"] == "completed"]
    assert len(tasks) == 2
    assert len({event["payload"]["attempt_id"] for event in tasks}) == 2
    for event in tasks:
        payload = event["payload"]
        label = payload["public_prompt"]
        assert payload["task_id"] == label
        assert payload["public_reply"] == f"reply-{label}"
        assert payload["invocation_id"] == payload["tool_run_id"]
        UUID(payload["attempt_id"])
        assert payload["attempt"] == "retry-label"
        jobs = [item for item in events if item["payload"].get("job_id") == f"job-{label}"]
        assert len(jobs) == 1
        assert jobs[0]["payload"]["invocation_id"] == payload["invocation_id"]
        assert jobs[0]["payload"]["task_id"] == label
        assert jobs[0]["payload"]["context_id"] == f"ctx-{label}"
    assert "private-job-token" not in str(events)
    assert "private-job-system" not in str(events)
    assert "private-reasoning" not in str(events)


def test_task_public_unicode_limits_terminal_dedup_and_retry_identity() -> None:
    events: list[dict[str, Any]] = []
    callback = RunEventCallback(events.append)
    identities = [uuid4(), uuid4()]
    for identity in identities:
        callback.on_tool_start(
            {"name": "task"},
            "private input_str",
            run_id=identity,
            inputs={"description": "题" * 5000, "task_id": "B", "system": "private-system"},
        )
        callback.on_tool_end(
            Command(
                update={
                    "messages": [
                        SystemMessage("private-system"),
                        ToolMessage(
                            content=[
                                {"type": "reasoning", "reasoning": "private-thought"},
                                {"type": "text", "text": "答" * 9000},
                            ],
                            tool_call_id="call",
                        ),
                    ]
                }
            ),
            run_id=identity,
        )
        callback.on_tool_end("late", run_id=identity)
        callback.on_tool_error(RuntimeError("private failure"), run_id=identity)
    assert len(events) == 4
    assert events[1]["payload"]["attempt_id"] != events[3]["payload"]["attempt_id"]
    assert len(events[1]["payload"]["public_prompt"]) == 4096
    assert len(events[1]["payload"]["public_reply"]) == 8192
    assert events[1]["payload"]["public_truncated"] is True
    assert "private" not in str(events)


@pytest.mark.parametrize(
    "error,status", [(RuntimeError("private details"), "failed"), (asyncio.CancelledError(), "unknown")]
)
def test_native_failure_cancel_remains_terminal(error: BaseException, status: str) -> None:
    events: list[dict[str, Any]] = []
    callback = RunEventCallback(events.append)
    identity = uuid4()
    callback.on_tool_start({"name": "task"}, "", run_id=identity, inputs={"description": "test"})
    callback.on_tool_error(error, run_id=identity)
    callback.on_tool_end("late success", run_id=identity)
    assert [event["status"] for event in events] == ["started", status]
    assert "private details" not in str(events)


@pytest.mark.asyncio
@pytest.mark.parametrize("mode", ["failed", "cancelled"])
async def test_real_native_entrypoint_failure_cancel_and_retry(mode: str) -> None:
    entered = asyncio.Event()
    release = asyncio.Event()

    async def child(state: dict[str, Any]) -> dict[str, Any]:
        entered.set()
        if mode == "failed":
            raise RuntimeError("private-child-failure")
        await release.wait()
        return {"messages": [AIMessage("done")]}

    events: list[dict[str, Any]] = []
    model = Model(
        responses=[
            AIMessage(
                "",
                tool_calls=[
                    {
                        "id": "same-call-label",
                        "name": "task",
                        "args": {"description": "work", "subagent_type": "worker", "task_id": "B"},
                    }
                ],
            ),
            AIMessage("done"),
        ]
    )
    graph = create_deep_agent(
        model=model,
        middleware=[NativeTaskMiddleware()],
        subagents=[{"name": "worker", "description": "Test worker", "runnable": RunnableLambda(child)}],
    )
    for _ in range(2):
        model.i = 0
        entered.clear()
        run = asyncio.create_task(
            graph.ainvoke(
                {"messages": [HumanMessage("Try")]},
                config={"callbacks": [RunEventCallback(events.append)], "configurable": {"octop_task_run_id": "root"}},
            )
        )
        await asyncio.wait_for(entered.wait(), timeout=5)
        if mode == "cancelled":
            run.cancel()
        with pytest.raises(asyncio.CancelledError if mode == "cancelled" else RuntimeError):
            await run
    terminals = [event for event in events if event["kind"] == "dispatch" and event["status"] != "started"]
    assert len(terminals) == 2
    assert [event["status"] for event in terminals] == ["unknown" if mode == "cancelled" else "failed"] * 2
    assert len({event["payload"]["attempt_id"] for event in terminals}) == 2
    assert len({event["payload"]["invocation_id"] for event in terminals}) == 2
    assert "private-child-failure" not in str(events)


def test_progress_emits_only_public_assistant_text_with_real_ancestry() -> None:
    from langchain_core.outputs import ChatGeneration, LLMResult

    events: list[dict[str, Any]] = []
    callback = RunEventCallback(events.append)
    native = uuid4()
    chain = uuid4()
    callback.on_tool_start({"name": "task"}, "", run_id=native, inputs={"description": "task"})
    callback.on_chain_start(None, {}, run_id=chain, parent_run_id=native)
    response = LLMResult(
        generations=[
            [
                ChatGeneration(
                    message=AIMessage(
                        content=[
                            {"type": "reasoning", "reasoning": "private-progress"},
                            {"type": "text", "text": "visible"},
                        ],
                        additional_kwargs={"private": "hidden"},
                    )
                )
            ]
        ]
    )
    callback.on_llm_end(response, run_id=uuid4(), parent_run_id=chain)
    assert events[-1]["payload"]["public_progress"] == "visible"
    assert events[-1]["event_id"] == events[0]["event_id"]
    assert "private-progress" not in str(events)
    assert "hidden" not in str(events)
    callback.on_tool_end("done", run_id=native)
    count = len(events)
    callback.on_llm_end(response, run_id=uuid4(), parent_run_id=chain)
    assert len(events) == count


@pytest.mark.asyncio
async def test_real_legacy_native_task_still_executes_without_associations() -> None:
    async def child(state: dict[str, Any]) -> dict[str, Any]:
        return {"messages": [AIMessage("legacy reply")]}

    graph = create_deep_agent(
        model=Model(
            responses=[
                AIMessage(
                    "",
                    tool_calls=[
                        {"id": "legacy", "name": "task", "args": {"description": "legacy", "subagent_type": "worker"}}
                    ],
                ),
                AIMessage("done"),
            ]
        ),
        middleware=[NativeTaskMiddleware()],
        subagents=[{"name": "worker", "description": "Test worker", "runnable": RunnableLambda(child)}],
    )
    events: list[dict[str, Any]] = []
    await graph.ainvoke({"messages": [HumanMessage("Legacy")]}, config={"callbacks": [RunEventCallback(events.append)]})
    event = next(item for item in events if item["kind"] == "dispatch" and item["status"] == "completed")
    assert event["payload"]["public_reply"] == "legacy reply"
    assert "task_id" not in event["payload"]


def test_cancelled_branch_never_terminates_unrelated_invocation() -> None:
    events: list[dict[str, Any]] = []
    callback = RunEventCallback(events.append)
    tasks = [uuid4(), uuid4()]
    branches = [uuid4(), uuid4()]
    for task_id, branch in zip(tasks, branches, strict=True):
        callback.on_tool_start({"name": "task"}, "", run_id=task_id, inputs={"description": "work"})
        callback.on_chain_start(None, {}, run_id=branch, parent_run_id=task_id)
    callback.on_chain_error(asyncio.CancelledError(), run_id=branches[0])
    callback.on_tool_end("second branch done", run_id=tasks[1])
    assert [event["status"] for event in events] == ["started", "started", "unknown", "completed"]
    assert events[2]["payload"]["invocation_id"] == str(tasks[0])
    assert events[3]["payload"]["invocation_id"] == str(tasks[1])


def test_public_text_redacts_secret_crossing_truncation_boundary() -> None:
    events: list[dict[str, Any]] = []
    callback = RunEventCallback(events.append)
    identity = uuid4()
    secret = "sk-" + "a" * 40
    callback.on_tool_start({"name": "task"}, "", run_id=identity, inputs={"description": "x " * 2040 + secret})
    callback.on_tool_end("x " * 4090 + secret, run_id=identity)
    assert "sk-" not in str(events)
    assert "[redacted]" in events[-1]["payload"]["public_reply"]


def test_nested_native_task_requires_its_own_explicit_plan_association() -> None:
    events: list[dict[str, Any]] = []
    callback = RunEventCallback(events.append)
    parent, child, tool_id = uuid4(), uuid4(), uuid4()
    callback.on_tool_start({"name": "task"}, "", run_id=parent, inputs={"description": "outer", "task_id": "B"})
    callback.on_tool_start({"name": "task"}, "", run_id=child, parent_run_id=parent, inputs={"description": "inner"})
    callback.on_tool_start({"name": "start_job"}, "", run_id=tool_id, parent_run_id=child)
    assert "task_id" not in events[-1]["payload"]
    assert "task_id" not in events[-2]["payload"]
    assert events[-1]["payload"]["invocation_id"] == str(child)
    assert events[-1]["payload"]["attempt_id"] == events[-2]["payload"]["attempt_id"]
