"""Run controls exercise real LangChain routing and checkpointed messages."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest
from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.language_models.fake_chat_models import FakeListChatModel, FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver

from octop_harness.protocols.langgraph import LangGraphProtocol
from octop_harness.steering import LiveSteeringMiddleware, StreamSteering


class ToolModel(FakeMessagesListChatModel):
    def bind_tools(self, tools: Any, **kwargs: Any) -> ToolModel:
        return self


def config(control: StreamSteering) -> dict[str, Any]:
    return {"configurable": {"thread_id": "test-thread", "harness_steering_run_id": control.run_id}}


async def consume(graph: Any, control: StreamSteering) -> list[dict[str, Any]]:
    chunks = []
    async for chunk in LangGraphProtocol(graph=graph).stream(
        [HumanMessage(content="original", id="original")], config(control)
    ):
        chunks.append(chunk)
    return chunks


@pytest.mark.asyncio
async def test_model_interruption_retains_partial_and_appends_user_once() -> None:
    control = StreamSteering()
    started = asyncio.Event()
    model_cancelled = asyncio.Event()

    class SlowFirst(AgentMiddleware[Any, Any]):
        first = True

        async def awrap_model_call(self, request: Any, handler: Any) -> Any:
            if self.first:
                self.first = False
                started.set()
                try:
                    await asyncio.Event().wait()
                except asyncio.CancelledError:
                    model_cancelled.set()
                    raise
            return await handler(request)

    graph = create_agent(
        ToolModel(responses=[AIMessage(content="updated")]),
        middleware=[LiveSteeringMiddleware({"test-thread": control}), SlowFirst()],
        checkpointer=InMemorySaver(),
    )
    task = asyncio.create_task(consume(graph, control))
    await asyncio.wait_for(started.wait(), 5)
    control.partial_text = "partial answer"
    assert control.request("insert-1", "new direction") == "accepted"
    chunks = await asyncio.wait_for(task, 5)
    assert model_cancelled.is_set()
    state = await graph.aget_state(config(control))
    assert [(m.type, m.content) for m in state.values["messages"]] == [
        ("human", "original"),
        ("ai", "partial answer"),
        ("human", "new direction"),
        ("ai", "updated"),
    ]
    assert [c["command_id"] for c in chunks if c["type"] == "steering_applied"] == ["insert-1"]
    assert control.request("insert-1", "new direction") == "applied"
    assert control.request("insert-1", "different") == "conflict"


@pytest.mark.asyncio
async def test_insertion_during_tool_finishes_side_effect_once_before_model() -> None:
    control = StreamSteering()
    started, release = asyncio.Event(), asyncio.Event()
    effects = []

    @tool
    async def save_once() -> str:
        """Record one synthetic side effect."""
        effects.append("saved")
        started.set()
        await release.wait()
        return "saved"

    graph = create_agent(
        ToolModel(
            responses=[
                AIMessage(content="", tool_calls=[{"name": "save_once", "args": {}, "id": "tool-1"}]),
                AIMessage(content="updated"),
            ]
        ),
        tools=[save_once],
        middleware=[LiveSteeringMiddleware({"test-thread": control})],
        checkpointer=InMemorySaver(),
    )
    task = asyncio.create_task(consume(graph, control))
    await asyncio.wait_for(started.wait(), 5)
    assert control.phase == "tool_running"
    control.request("insert-2", "stop after saving")
    await asyncio.sleep(0)
    assert not task.done()
    release.set()
    await asyncio.wait_for(task, 5)
    state = await graph.aget_state(config(control))
    assert effects == ["saved"]
    messages = state.values["messages"]
    assert [m.content for m in messages if m.type == "human"] == ["original", "stop after saving"]
    assert next(i for i, m in enumerate(messages) if m.type == "tool") < next(
        i for i, m in enumerate(messages) if m.id == "steer:insert-2"
    )


@pytest.mark.asyncio
async def test_insertion_before_tool_discards_stale_call_and_replans() -> None:
    control = StreamSteering()
    effects = []

    @tool
    async def never_run() -> str:
        """Must not execute a superseded plan."""
        effects.append("bad")
        return "bad"

    class InsertAfterModel(AgentMiddleware[Any, Any]):
        async def aafter_model(self, state: Any, runtime: Any) -> None:
            if getattr(state["messages"][-1], "tool_calls", None):
                control.request("insert-3", "different plan")

    graph = create_agent(
        ToolModel(
            responses=[
                AIMessage(
                    content="about to save",
                    tool_calls=[{"name": "never_run", "args": {}, "id": "tool-1"}],
                    additional_kwargs={
                        "tool_calls": [
                            {"id": "tool-1", "type": "function", "function": {"name": "never_run", "arguments": "{}"}}
                        ]
                    },
                ),
                AIMessage(content="replanned"),
            ]
        ),
        tools=[never_run],
        middleware=[LiveSteeringMiddleware({"test-thread": control}), InsertAfterModel()],
        checkpointer=InMemorySaver(),
    )
    await asyncio.wait_for(consume(graph, control), 5)
    state = await graph.aget_state(config(control))
    assert effects == []
    assert not any(getattr(m, "tool_calls", None) for m in state.values["messages"])
    from langchain_openai.chat_models.base import _convert_message_to_dict

    assert not any(_convert_message_to_dict(m).get("tool_calls") for m in state.values["messages"])
    assert [m.content for m in state.values["messages"] if m.type == "human"] == ["original", "different plan"]


@pytest.mark.asyncio
async def test_idless_empty_tool_call_is_removed_before_replanning() -> None:
    control = StreamSteering()
    effects = []

    @tool
    async def never_run() -> str:
        """Must not execute a superseded plan."""
        effects.append("bad")
        return "bad"

    class InsertWithIdlessTail(AgentMiddleware[Any, Any]):
        async def aafter_model(self, state: Any, runtime: Any) -> None:
            last = state["messages"][-1]
            if getattr(last, "tool_calls", None):
                last.id = None
                control.request("insert-idless", "different plan")

    graph = create_agent(
        ToolModel(
            responses=[
                AIMessage(content="", tool_calls=[{"name": "never_run", "args": {}, "id": "tool-idless"}]),
                AIMessage(content="replanned"),
            ]
        ),
        tools=[never_run],
        middleware=[LiveSteeringMiddleware({"test-thread": control}), InsertWithIdlessTail()],
        checkpointer=InMemorySaver(),
    )
    await asyncio.wait_for(consume(graph, control), 5)
    state = await graph.aget_state(config(control))
    messages = state.values["messages"]
    assert effects == []
    assert not any(getattr(message, "tool_calls", None) for message in messages)
    assert [message.content for message in messages if message.type == "human"] == [
        "original",
        "different plan",
    ]
    assert messages[-1].content == "replanned"


@pytest.mark.asyncio
async def test_insertion_before_first_model_is_applied_without_generation() -> None:
    control = StreamSteering()
    control.request("insert-4", "before model")
    graph = create_agent(
        ToolModel(responses=[AIMessage(content="done")]),
        middleware=[LiveSteeringMiddleware({"test-thread": control})],
        checkpointer=InMemorySaver(),
    )
    await asyncio.wait_for(consume(graph, control), 5)
    state = await graph.aget_state(config(control))
    assert [m.content for m in state.values["messages"] if m.type == "human"] == ["original", "before model"]


@pytest.mark.asyncio
async def test_real_stream_tokens_survive_interrupted_model_checkpoint() -> None:
    control = StreamSteering()

    class StreamingModel(FakeListChatModel):
        def bind_tools(self, tools: Any, **kwargs: Any) -> StreamingModel:
            return self

    graph = create_agent(
        StreamingModel(responses=["original long answer", "updated"], sleep=0.02),
        middleware=[LiveSteeringMiddleware({"test-thread": control})],
        checkpointer=InMemorySaver(),
    )
    inserted = False
    visible_tokens = []
    async for chunk in LangGraphProtocol(graph=graph).stream(
        [HumanMessage(content="original", id="original")], config(control)
    ):
        if chunk.get("type") == "token":
            visible_tokens.append(chunk["content"])
            control.partial_text += chunk["content"]
            if not inserted:
                inserted = True
                control.request("stream-insert", "new direction")
    assert inserted
    assert "".join(visible_tokens) == "oupdated"
    state = await graph.aget_state(config(control))
    messages = state.values["messages"]
    assert [(m.type, m.content) for m in messages] == [
        ("human", "original"),
        ("ai", "o"),
        ("human", "new direction"),
        ("ai", "updated"),
    ]
    assert messages[1].additional_kwargs["octop_interrupted"] is True


@pytest.mark.asyncio
async def test_external_cancellation_drains_model_handler() -> None:
    control = StreamSteering()
    started, cancelled = asyncio.Event(), asyncio.Event()

    class Blocking(AgentMiddleware[Any, Any]):
        async def awrap_model_call(self, request: Any, handler: Any) -> Any:
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                cancelled.set()

    graph = create_agent(
        ToolModel(responses=[AIMessage(content="unused")]),
        middleware=[LiveSteeringMiddleware({"test-thread": control}), Blocking()],
        checkpointer=InMemorySaver(),
    )
    task = asyncio.create_task(consume(graph, control))
    await asyncio.wait_for(started.wait(), 5)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert cancelled.is_set()


@pytest.mark.asyncio
async def test_last_model_boundary_accepts_input_before_stream_finishes() -> None:
    from octop_harness.agent import HarnessAgent

    agent = HarnessAgent.__new__(HarnessAgent)
    agent._steering_runs = {}
    agent._cancel_events = {}
    graph = create_agent(
        ToolModel(responses=[AIMessage(content="first"), AIMessage(content="second")]),
        middleware=[LiveSteeringMiddleware(agent._steering_runs)],
        checkpointer=InMemorySaver(),
    )
    inserted = False
    async for chunk in agent._stream_with_steering(
        LangGraphProtocol(graph=graph),
        [HumanMessage(content="original", id="original")],
        {"configurable": {"thread_id": "test-thread"}},
        "test-thread",
    ):
        if chunk.get("type") == "run_phase" and chunk.get("phase") == "llm_after" and not inserted:
            inserted = True
            runtime = agent.steering_status("test-thread")
            assert runtime is not None
            assert (
                agent.steer_message("test-thread", "last-boundary", "next direction", run_id=runtime["run_id"])[
                    "status"
                ]
                == "accepted"
            )
    state = await graph.aget_state({"configurable": {"thread_id": "test-thread"}})
    assert [m.content for m in state.values["messages"] if m.type == "human"] == ["original", "next direction"]
    assert state.values["messages"][-1].content == "second"
    assert agent.steering_status("test-thread") is None


@pytest.mark.asyncio
async def test_hitl_resume_remains_steerable_without_replaying_approved_tool() -> None:
    from langchain.agents.middleware import HumanInTheLoopMiddleware

    from octop_harness.agent import HarnessAgent

    bare = HarnessAgent.__new__(HarnessAgent)
    bare._steering_runs = {}
    bare._cancel_events = {}
    started, release = asyncio.Event(), asyncio.Event()
    effects = []

    @tool
    async def approved_save() -> str:
        """An approved synthetic side effect."""
        effects.append("saved")
        started.set()
        await release.wait()
        return "saved"

    graph = create_agent(
        ToolModel(
            responses=[
                AIMessage(content="", tool_calls=[{"name": "approved_save", "args": {}, "id": "approved"}]),
                AIMessage(content="updated"),
            ]
        ),
        tools=[approved_save],
        middleware=[
            LiveSteeringMiddleware(bare._steering_runs),
            HumanInTheLoopMiddleware(interrupt_on={"approved_save": True}),
        ],
        checkpointer=InMemorySaver(),
    )
    proto = LangGraphProtocol(graph=graph)
    cfg = {"configurable": {"thread_id": "test-thread"}}
    initial = [
        chunk
        async for chunk in bare._stream_with_steering(
            proto, [HumanMessage(content="original", id="original")], cfg, "test-thread"
        )
    ]
    assert any(c.get("type") == "hitl_required" for c in initial)
    assert initial[-1]["phase"] == "paused"
    assert bare.steering_status("test-thread") is None

    async def resume():
        return [
            chunk
            async for chunk in bare._stream_with_steering(
                proto, [], cfg, "test-thread", decisions=[{"type": "approve"}]
            )
        ]

    task = asyncio.create_task(resume())
    await asyncio.wait_for(started.wait(), 5)
    runtime = bare.steering_status("test-thread")
    assert runtime is not None
    assert (
        bare.steer_message("test-thread", "resume-insert", "after approval", run_id=runtime["run_id"])["status"]
        == "accepted"
    )
    release.set()
    await asyncio.wait_for(task, 5)
    state = await graph.aget_state(cfg)
    assert effects == ["saved"]
    assert [m.content for m in state.values["messages"] if m.type == "human"] == ["original", "after approval"]


def test_run_identity_and_busy_admission_are_explicit() -> None:
    from octop_harness.agent import HarnessAgent

    bare = HarnessAgent.__new__(HarnessAgent)
    control = StreamSteering()
    bare._steering_runs = {"thread": control}
    assert bare.steer_message("thread", "id", "text", run_id="old")["status"] == "stale_run"
    assert control.pending is None
    assert bare.steer_message("thread", "id", "text", run_id=control.run_id)["status"] == "accepted"
    assert bare.steer_message("thread", "another", "text", run_id=control.run_id)["status"] == "busy"
    control.phase = "paused"
    assert bare.steer_message("thread", "third", "text", run_id=control.run_id)["status"] == "inactive"
