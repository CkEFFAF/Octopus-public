"""Public append behavior against real compiled graphs and checkpoint storage."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.errors import InvalidUpdateError
from langgraph.graph import END, START, MessagesState, StateGraph

from octop_harness import ChatRequest, HarnessAgent, HarnessAgentConfig, ModelConfig, ProviderConfig


class Model(FakeMessagesListChatModel):
    def bind_tools(self, tools: Any, **kwargs: Any) -> Any:
        return self


@pytest.fixture
def real_agent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> tuple[HarnessAgent, Model]:
    model = Model(responses=[AIMessage("first answer"), AIMessage("second answer")])
    monkeypatch.setattr("octop_harness.llm.factory.ChatModelFactory.get_chat_model", lambda *args, **kwargs: model)
    config = HarnessAgentConfig(
        name="append-checkpoint",
        workspace_dir=tmp_path,
        backend={"type": "filesystem", "root_dir": str(tmp_path), "virtual_mode": True},
        providers=[
            ProviderConfig(id="p", base_url="https://example.invalid", api_key="fake", models=[ModelConfig(id="text")])
        ],
        default_model="p/text",
        memory_enabled=False,
        checkpointer=InMemorySaver(),
    )
    return HarnessAgent(config), model


@pytest.mark.asyncio
async def test_append_after_real_parallel_writers(real_agent: tuple[HarnessAgent, Model]) -> None:
    agent, _ = real_agent
    builder = StateGraph(MessagesState)
    builder.add_node("left", lambda state: {"messages": [AIMessage("left", id="left")]})
    builder.add_node("right", lambda state: {"messages": [AIMessage("right", id="right")]})
    for name in ("left", "right"):
        builder.add_edge(START, name)
        builder.add_edge(name, END)
    graph = builder.compile(checkpointer=agent._checkpointer_instance)
    agent._graph = graph
    config = {"configurable": {"thread_id": "parallel"}}
    await graph.ainvoke({"messages": [HumanMessage("hello", id="initial")]}, config)
    assert (await graph.aget_state(config)).next == ()
    # This is a real ambiguous checkpoint, rather than an AsyncMock of the failure.
    with pytest.raises(InvalidUpdateError, match="Ambiguous update"):
        await graph.aupdate_state(config, {"messages": [AIMessage("unsafe")]})
    appended = await agent.aappend_messages("parallel", [AIMessage("cron", id="cron")])
    assert [m.id for m in await agent.aget_history("parallel")] == ["initial", "left", "right", "cron"]
    await agent.aappend_messages("parallel", appended)
    await agent.aappend_messages("parallel", [AIMessage("second cron", id="cron2")])
    assert [m.id for m in await agent.aget_history("parallel")] == ["initial", "left", "right", "cron", "cron2"]


@pytest.mark.asyncio
async def test_real_harness_append_does_not_invoke_model_and_next_turn_works(
    real_agent: tuple[HarnessAgent, Model],
) -> None:
    agent, model = real_agent
    await agent.call(ChatRequest(messages=[HumanMessage("hello", id="initial")], thread_id="harness"))
    assert model.i == 1
    appended = await agent.aappend_messages(
        "harness", [HumanMessage("scheduled", id="cron-human"), AIMessage("reminder", id="cron-ai")]
    )
    await agent.aappend_messages("harness", appended)
    await agent.aappend_messages("harness", [AIMessage("second reminder", id="cron2")])
    assert model.i == 1
    assert [m.id for m in await agent.aget_history("harness")][-3:] == ["cron-human", "cron-ai", "cron2"]
    await agent.call(ChatRequest(messages=[HumanMessage("continue", id="continue")], thread_id="harness"))
    assert model.i == 0
    history = await agent.aget_history("harness")
    assert [m.id for m in history].count("cron-ai") == 1
    assert [m.content for m in history][-2:] == ["continue", "second answer"]


@pytest.mark.asyncio
async def test_append_survives_sqlite_reopen(real_agent: tuple[HarnessAgent, Model], tmp_path: Path) -> None:
    from dataclasses import replace

    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    prototype, model = real_agent
    db = str(tmp_path / "reopened.sqlite")
    async with AsyncSqliteSaver.from_conn_string(db) as saver:
        agent = HarnessAgent(replace(prototype.config, checkpointer=saver))
        agent._graph = agent._graph.with_config({"metadata": {"trace_reference": "trace-kept"}})
        await agent.call(ChatRequest(messages=[HumanMessage("hello")], thread_id="reopen"))
        appended = await agent.aappend_messages("reopen", [AIMessage("scheduled", id="cron")])
        state = await agent._graph.aget_state({"configurable": {"thread_id": "reopen"}})
        assert state.metadata["trace_reference"] == "trace-kept"
        assert state.metadata["octop_history_append_step"] == state.metadata["step"]
        agent.close()
    async with AsyncSqliteSaver.from_conn_string(db) as saver:
        reopened = HarnessAgent(replace(prototype.config, checkpointer=saver))
        await reopened.aappend_messages("reopen", appended)
        await reopened.aappend_messages("reopen", [AIMessage("next scheduled", id="cron2")])
        assert model.i == 1
        assert [m.id for m in await reopened.aget_history("reopen")].count("cron") == 1
        await reopened.call(ChatRequest(messages=[HumanMessage("continue")], thread_id="reopen"))
        state = await reopened._graph.aget_state({"configurable": {"thread_id": "reopen"}})
        assert state.next == ()
        assert state.metadata["source"] == "loop"
        assert state.metadata.get("octop_history_append_step") != state.metadata["step"]
        await reopened.aappend_messages("reopen", [AIMessage("after turn", id="cron3")])
        assert [m.id for m in await reopened.aget_history("reopen")][-1] == "cron3"
        reopened.close()


@pytest.mark.asyncio
@pytest.mark.parametrize("mode", ["interrupt", "static", "error", "external_update"])
async def test_pending_work_is_rejected_without_checkpoint_mutation(
    real_agent: tuple[HarnessAgent, Model], mode: str
) -> None:
    from langgraph.types import Command, interrupt

    agent, _ = real_agent
    calls: list[str] = []

    def work(state: MessagesState) -> dict[str, Any]:
        calls.append("work")
        if mode == "interrupt":
            interrupt("approval required")
        if mode == "error":
            raise ValueError("tool failed")
        return {"messages": [AIMessage("completed tool", id="tool-result")]}

    builder = StateGraph(MessagesState)
    builder.add_node("work", work)
    builder.add_edge(START, "work")
    builder.add_edge("work", END)
    graph = builder.compile(
        checkpointer=agent._checkpointer_instance, interrupt_before=["work"] if mode == "static" else None
    )
    agent._graph = graph
    config = {"configurable": {"thread_id": "pending"}}
    # First append creates the marker. Advancing the graph must invalidate it,
    # including when the pending node is also exactly the START entry node.
    await agent.aappend_messages("pending", [HumanMessage("scheduled", id="cron")])
    if mode == "external_update":
        state = await graph.aget_state(config)
        await graph.aupdate_state(
            {**config, "metadata": {"octop_history_append_step": state.metadata["octop_history_append_step"]}},
            {"messages": [HumanMessage("external", id="external")]},
            as_node=START,
        )
    elif mode == "static":
        await graph.ainvoke({"messages": [HumanMessage("new input", id="new")]}, config)
    elif mode == "error":
        with pytest.raises(ValueError, match="tool failed"):
            await graph.ainvoke(None, config)
    else:
        await graph.ainvoke(None, config)
    before = await graph.aget_state(config)
    assert before.next == ("work",)
    if mode in {"external_update", "static"}:
        assert (
            before.metadata.get("octop_history_append_step") != before.metadata["step"]
            or before.metadata["source"] != "update"
        )
    with pytest.raises(RuntimeError, match="pending work"):
        await agent.aappend_messages("pending", [AIMessage("do not inject", id="blocked")])
    after = await graph.aget_state(config)
    assert after.config == before.config
    assert after.values == before.values
    assert after.tasks == before.tasks
    assert all(m.id != "blocked" for m in await agent.aget_history("pending"))
    if mode == "interrupt":
        assert calls == ["work"]
        await graph.ainvoke(Command(resume=True), config)
        assert calls == ["work", "work"]
        assert (await graph.aget_state(config)).next == ()
