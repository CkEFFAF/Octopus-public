"""Public native-task associations; execution remains owned by DeepAgents."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from contextvars import ContextVar
from typing import Any

from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.types import Command
from pydantic import BaseModel, Field, create_model

native_task_association: ContextVar[dict[str, Any] | None] = ContextVar("native_task_association", default=None)


class NativeTaskMiddleware(AgentMiddleware[Any, Any]):
    """Expose optional plan task/attempt labels without changing task scheduling.

    Hosts validate task IDs against the current authorized run's plan. ``attempt``
    is a caller label; the observation callback generates the authoritative UUID.
    All existing task arguments and validation remain intact.
    """

    @staticmethod
    def _prepare(request: ModelRequest) -> ModelRequest:
        tools = []
        for original in request.tools:
            tool = original
            schema = getattr(tool, "args_schema", None)
            if (
                isinstance(tool, BaseTool)
                and tool.name == "task"
                and isinstance(schema, type)
                and issubclass(schema, BaseModel)
            ):
                extended = create_model(
                    "AssociatedTaskSchema",
                    __base__=schema,
                    task_id=(
                        str | None,
                        Field(
                            default=None, max_length=200, description="Task ID in the current run's explicit work_plan."
                        ),
                    ),
                    attempt=(
                        str | None,
                        Field(
                            default=None,
                            max_length=200,
                            description="Optional retry label; runtime generates attempt identity.",
                        ),
                    ),
                )
                tool = tool.model_copy(update={"args_schema": extended})
            tools.append(tool)
        return request.override(tools=tools)

    def wrap_model_call(self, request: ModelRequest, handler: Callable[[ModelRequest], ModelResponse]) -> ModelResponse:
        return handler(self._prepare(request))

    async def awrap_model_call(
        self, request: ModelRequest, handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        return await handler(self._prepare(request))

    @staticmethod
    def _association(request: ToolCallRequest) -> tuple[ToolCallRequest, dict[str, Any]]:
        if request.tool_call["name"] != "task":
            return request, {}
        args = dict(request.tool_call["args"])
        association = {}
        for key in ("task_id", "attempt"):
            value = args.pop(key, None)
            if value is not None:
                if not isinstance(value, str) or not value or len(value) > 200:
                    raise ValueError(f"{key} must be a nonempty string of at most 200 characters")
                association[key] = value
        return request.override(tool_call={**request.tool_call, "args": args}), association

    def wrap_tool_call(
        self, request: ToolCallRequest, handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]]
    ) -> ToolMessage | Command[Any]:
        prepared, association = self._association(request)
        token = native_task_association.set(association)
        try:
            return handler(prepared)
        finally:
            native_task_association.reset(token)

    async def awrap_tool_call(
        self, request: ToolCallRequest, handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]]
    ) -> ToolMessage | Command[Any]:
        prepared, association = self._association(request)
        token = native_task_association.set(association)
        try:
            return await handler(prepared)
        finally:
            native_task_association.reset(token)


__all__ = ["NativeTaskMiddleware"]
