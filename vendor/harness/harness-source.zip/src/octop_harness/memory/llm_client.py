"""``HarnessAgentLLMClient`` — adapt the agent's models to octop-memory.

``octop-memory``'s extractor / promotion / page-regen paths talk to the
host model through the :class:`octop_memory.ports.llm.LLMClient` protocol. This
module wraps the agent's existing :class:`ChatModelFactory` so we can reuse
the same providers and credentials the rest of the agent already uses.

Model selection
---------------
Extract uses **one** model, not a light/heavy pair. Resolution order:

1. optional aux override (``aux_model``, or the legacy light/heavy aliases)
2. the live chat model (:meth:`set_current_model`)
3. the agent's ``default_model``

``tier`` only changes the timeout. If a ref fails (expired subscription,
400, missing model), ``call_llm`` tries the next one in that list.

Failure discipline
------------------
Any transport / model error is wrapped in :class:`LLMClientError` so the
plugin's extractor / promotion worker can degrade gracefully (write the
``failure_reason`` and move on) — never bubble into the user reply path.
"""

from __future__ import annotations

import logging
import re
import threading
from typing import TYPE_CHECKING, Any, Literal

from octop_memory.ports.llm import LLMClientError, LLMTier

from octop_harness.llm.invoke_helpers import bind_call_options, build_text_messages, stringify_content

if TYPE_CHECKING:
    from octop_harness.llm.factory import ChatModelFactory

logger = logging.getLogger(__name__)

# Model ids that start a reasoning chain unless the request turns it off.
# Matched against the model id (the part after the last "/"), not the provider.
_REASONING_MODEL_RE = re.compile(
    r"(qwen3|qwen-3|qwq|deepseek-r\d|reasoner|(?:^|[^a-z])thinking(?:[^a-z]|$))",
    re.IGNORECASE,
)
ThinkingMode = Literal["auto", "off", "on"]


class HarnessAgentLLMClient:
    """Adapter from :class:`ChatModelFactory` to :class:`LLMClient`.

    Args:
        factory: The agent's model factory; used to build / cache
            ``BaseChatModel`` instances by ``"<provider>/<model>"`` ref.
        aux_model: Optional extract override. When unset, extract follows
            the live chat model and then ``default_model``.
        light_model / heavy_model: Legacy aliases for ``aux_model``. The
            first non-empty value wins; both tiers share it.
        default_model: Last-resort model ref when no aux and no live chat
            model have been recorded yet.
        thinking: ``auto`` disables depth-thinking for known reasoning model
            ids; ``off`` disables it for every OpenAI-compatible model;
            ``on`` leaves the server default. Main-chat thinking settings
            are not applied to this client.
    """

    # Default timeouts in seconds. Light covers per-session extraction and alias
    # disambiguation; heavy covers cross-session consolidation. Hard caps prevent
    # upstream gateway stalls or slow inference from blocking extract threads.
    DEFAULT_LIGHT_TIMEOUT_S: float = 120.0
    DEFAULT_HEAVY_TIMEOUT_S: float = 300.0

    def __init__(
        self,
        factory: ChatModelFactory,
        *,
        aux_model: str | None = None,
        light_model: str | None = None,
        heavy_model: str | None = None,
        default_model: str | None = None,
        light_timeout_s: float | None = None,
        heavy_timeout_s: float | None = None,
        thinking: ThinkingMode = "auto",
    ) -> None:
        configured = _first_ref(aux_model, light_model, heavy_model)
        if configured is None and default_model is None:
            raise ValueError(
                "HarnessAgentLLMClient requires aux_model or default_model",
            )
        self._factory = factory
        self._aux_model = configured
        self._default_model = default_model
        self._light_timeout_s = light_timeout_s if light_timeout_s is not None else self.DEFAULT_LIGHT_TIMEOUT_S
        self._heavy_timeout_s = heavy_timeout_s if heavy_timeout_s is not None else self.DEFAULT_HEAVY_TIMEOUT_S
        self._thinking: ThinkingMode = thinking
        self._current_lock = threading.Lock()
        self._current_model: str | None = None

    def set_current_model(self, ref: str | None) -> None:
        """Record the model the user is actually chatting with.

        When no aux override is set, extract uses this ref. When aux is
        set and fails, extract retries here.
        """
        value = ref.strip() if isinstance(ref, str) and ref.strip() else None
        with self._current_lock:
            self._current_model = value

    # ------------------------------------------------------------------
    # LLMClient protocol
    # ------------------------------------------------------------------

    def call_llm(
        self,
        prompt: str,
        *,
        tier: LLMTier = "light",
        system: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        response_format: Literal["text", "json"] = "text",
    ) -> str:
        refs = self._candidate_refs()
        if not refs:
            raise LLMClientError(f"no model configured for tier={tier!r}")

        last_exc: BaseException | None = None
        for index, ref in enumerate(refs):
            try:
                return self._invoke_ref(
                    ref,
                    prompt,
                    tier=tier,
                    system=system,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    response_format=response_format,
                )
            except Exception as exc:  # provider error types vary; try the next ref; pylint: disable=broad-except
                last_exc = exc
                next_ref = refs[index + 1] if index + 1 < len(refs) else None
                if next_ref is None:
                    break
                logger.info(
                    "HarnessAgentLLMClient: %s failed for tier=%s; falling back to %s: %r (%s)",
                    ref,
                    tier,
                    next_ref,
                    exc,
                    type(exc).__name__,
                )

        assert last_exc is not None
        failed_ref = refs[-1]
        detail = str(last_exc).strip() or type(last_exc).__name__
        raise LLMClientError(
            f"chat model {failed_ref!r} failed for tier={tier!r}: {detail}",
        ) from last_exc

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _candidate_refs(self) -> list[str]:
        """Return distinct refs: aux override, then live chat, then default."""
        with self._current_lock:
            current = self._current_model
        ordered: list[str] = []
        seen: set[str] = set()
        for ref in (self._aux_model, current, self._default_model):
            stripped = _first_ref(ref)
            if stripped is None or stripped in seen:
                continue
            seen.add(stripped)
            ordered.append(stripped)
        return ordered

    def _invoke_ref(
        self,
        ref: str,
        prompt: str,
        *,
        tier: LLMTier,
        system: str | None,
        max_tokens: int | None,
        temperature: float | None,
        response_format: Literal["text", "json"],
    ) -> str:
        try:
            model = self._factory.get_chat_model(ref)
        except Exception as exc:
            detail = str(exc).strip() or type(exc).__name__
            raise LLMClientError(
                f"failed to build chat model {ref!r} for tier={tier!r}: {detail}",
            ) from exc

        bound_model = bind_call_options(
            model,
            max_tokens=max_tokens,
            temperature=temperature,
            response_format=response_format,
            timeout_s=self._light_timeout_s if tier == "light" else self._heavy_timeout_s,
            extra_body=_disable_thinking_extra_body(ref, self._thinking),
        )
        messages = build_text_messages(prompt, system=system)

        try:
            response = bound_model.invoke(messages)
        except Exception as exc:
            # Provider 400s (expired subscription, bad request) are not
            # always RuntimeError/OSError subclasses. Treat every model
            # failure as degrade-able so extract never kills the user turn.
            logger.info(
                "HarnessAgentLLMClient.call_llm failed (model=%s, tier=%s): %r (%s)",
                ref,
                tier,
                exc,
                type(exc).__name__,
            )
            detail = str(exc).strip() or type(exc).__name__
            raise LLMClientError(
                f"chat model {ref!r} failed for tier={tier!r}: {detail}",
            ) from exc

        return stringify_content(response.content)


def _disable_thinking_extra_body(ref: str, mode: ThinkingMode) -> dict[str, Any] | None:
    """Return the OpenAI-compatible body that turns reasoning off, or None.

    ``enable_thinking`` is a chat-template flag used by Qwen3 / vLLM-style
    servers. Official OpenAI rejects unknown body fields, so ``auto`` only
    attaches it when the model id looks like a default-on reasoning model.
    """
    if mode == "on":
        return None
    if mode == "auto":
        model_id = ref.rsplit("/", 1)[-1]
        if _REASONING_MODEL_RE.search(model_id) is None:
            return None
    return {"chat_template_kwargs": {"enable_thinking": False}}


def _first_ref(*refs: str | None) -> str | None:
    for ref in refs:
        if isinstance(ref, str) and ref.strip():
            return ref.strip()
    return None


__all__ = ["HarnessAgentLLMClient"]
