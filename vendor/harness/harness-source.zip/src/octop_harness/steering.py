"""Cooperative message insertion at model and tool execution boundaries."""

from __future__ import annotations

import asyncio
import contextlib
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse
from langchain.agents.middleware.types import ToolCallRequest, hook_config
from langchain_core.messages import AIMessage, HumanMessage, RemoveMessage, ToolMessage
from langgraph.config import get_config, get_stream_writer
from langgraph.runtime import Runtime
from langgraph.types import Command, Overwrite


@dataclass
class SteeringCommand:
    command_id: str
    text: str


@dataclass
class StreamSteering:
    """Loop-local control for one identified invocation; persistence belongs to hosts."""

    run_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    wake: asyncio.Event = field(default_factory=asyncio.Event)
    phase: str = "llm_before"
    pending: SteeringCommand | None = None
    partial_text: str = ""
    command_status: dict[str, str] = field(default_factory=dict)
    command_text: dict[str, str] = field(default_factory=dict)
    active_tools: int = 0
    interrupted_model: bool = False

    def request(self, command_id: str, text: str) -> str:
        if command_id in self.command_status:
            return self.command_status[command_id] if self.command_text[command_id] == text else "conflict"
        if self.phase in {"paused", "completed", "failed", "cancelled"}:
            return "inactive"
        if self.pending is not None:
            return "busy"
        self.pending = SteeringCommand(command_id=command_id, text=text)
        self.command_status[command_id] = "accepted"
        self.command_text[command_id] = text
        self.wake.set()
        return "accepted"

    def observe(self, chunk: Any) -> bool:
        """Capture public output and close admission on an approval pause."""
        if not isinstance(chunk, dict):
            return False
        if chunk.get("type") == "token":
            self.partial_text += str(chunk.get("content") or "")
        elif chunk.get("type") == "hitl_required":
            self.phase = "paused"
            return True
        return False

    def phase_event(self, thread_id: str) -> dict[str, Any]:
        return {"type": "run_phase", "run_id": self.run_id, "thread_id": thread_id, "phase": self.phase}


class LiveSteeringMiddleware(AgentMiddleware[Any, Any]):
    """Cancel only a model handler; admit tools atomically and let them finish.

    After-model updates jump back to the model so superseded tool calls never
    run. Requests admitted during tool execution are consumed by before-model
    once the tools superstep has completed. No graph iterator is cancelled.
    """

    def __init__(self, controls: dict[str, StreamSteering]) -> None:
        self.controls = controls

    def _control(self) -> tuple[str, StreamSteering] | None:
        cfg = get_config().get("configurable") or {}
        thread_id = str(cfg.get("thread_id") or "")
        control = self.controls.get(thread_id)
        if control is None or cfg.get("harness_steering_run_id") != control.run_id:
            return None
        return thread_id, control

    @staticmethod
    def _emit(event: dict[str, Any]) -> None:
        get_stream_writer()({"__harness_steering__": event})

    def _phase(self, thread_id: str, control: StreamSteering, phase: str) -> None:
        control.phase = phase
        self._emit(control.phase_event(thread_id))

    def _apply(self, state: Any, control: StreamSteering, *, after_model: bool) -> dict[str, Any] | None:
        command = control.pending
        if command is None:
            return None
        boundary = control.phase
        updates: list[Any] = []
        messages = state.get("messages", [])
        last = messages[-1] if messages else None
        replace_message_state = False
        if after_model and isinstance(last, AIMessage):
            if last.tool_calls:
                if last.content:
                    updates.append(
                        last.model_copy(
                            update={
                                "tool_calls": [],
                                "invalid_tool_calls": [],
                                "additional_kwargs": {
                                    **{
                                        key: value
                                        for key, value in last.additional_kwargs.items()
                                        if key not in {"tool_calls", "function_call"}
                                    },
                                    "octop_interrupted": True,
                                },
                            }
                        )
                    )
                elif last.id:
                    updates.append(RemoveMessage(id=last.id))
                else:
                    # RemoveMessage requires an ID. Replacing the reducer state
                    # safely drops an id-less tail message before appending the
                    # steering input, so its stale tool calls cannot be replayed.
                    replace_message_state = True
            elif control.interrupted_model and not last.content and last.id:
                updates.append(RemoveMessage(id=last.id))
            elif control.interrupted_model and not last.content:
                replace_message_state = True
        updates.append(HumanMessage(content=command.text, id=f"steer:{command.command_id}"))
        control.pending = None
        control.wake.clear()
        control.command_status[command.command_id] = "applied"
        self._emit(
            {
                "type": "steering_applied",
                "command_id": command.command_id,
                "run_id": control.run_id,
                "phase": boundary,
                "partial_output_retained": bool(control.partial_text) and control.interrupted_model,
            }
        )
        self._emit(
            {
                "type": "user",
                "content": command.text,
                "command_id": command.command_id,
                "source": "dashboard_insert",
                "run_id": control.run_id,
            }
        )
        control.interrupted_model = False
        result: dict[str, Any] = {
            "messages": Overwrite([*messages[:-1], *updates]) if replace_message_state else updates
        }
        if after_model:
            result["jump_to"] = "model"
        return result

    async def abefore_model(self, state: Any, runtime: Runtime[Any]) -> dict[str, Any] | None:
        active = self._control()
        if active is None:
            return None
        thread_id, control = active
        self._phase(thread_id, control, "llm_before")
        return self._apply(state, control, after_model=False)

    @hook_config(can_jump_to=["model"])
    async def aafter_model(self, state: Any, runtime: Runtime[Any]) -> dict[str, Any] | None:
        active = self._control()
        if active is None:
            return None
        thread_id, control = active
        messages = state.get("messages", [])
        last = messages[-1] if messages else None
        self._phase(thread_id, control, "tool_before" if getattr(last, "tool_calls", None) else "llm_after")
        return self._apply(state, control, after_model=True)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        active = self._control()
        if active is None:
            return await handler(request)
        thread_id, control = active
        control.partial_text = ""
        control.interrupted_model = False
        self._phase(thread_id, control, "llm_running")
        model_task = asyncio.ensure_future(handler(request))
        wake_task = asyncio.create_task(control.wake.wait())
        try:
            done, _ = await asyncio.wait({model_task, wake_task}, return_when=asyncio.FIRST_COMPLETED)
            if model_task in done:
                return await model_task
            model_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await model_task
            control.interrupted_model = True
            return ModelResponse(
                result=[
                    AIMessage(
                        content=control.partial_text,
                        additional_kwargs={"octop_partial": True, "octop_interrupted": True},
                    )
                ]
            )
        finally:
            for task in (model_task, wake_task):
                if not task.done():
                    task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        active = self._control()
        if active is None:
            return await handler(request)
        thread_id, control = active
        if control.pending is not None:
            return ToolMessage(
                content="Tool call superseded by a new user instruction before execution.",
                tool_call_id=request.tool_call["id"],
                name=request.tool_call["name"],
                additional_kwargs={"octop_superseded": True},
            )
        control.active_tools += 1
        self._phase(thread_id, control, "tool_running")
        try:
            return await handler(request)
        finally:
            control.active_tools -= 1
            if not control.active_tools:
                self._phase(thread_id, control, "tool_after")


__all__ = ["LiveSteeringMiddleware", "SteeringCommand", "StreamSteering"]
