"""Cooperative message insertion at model and tool execution boundaries."""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import uuid
from collections.abc import Awaitable, Callable
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any

from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse
from langchain.agents.middleware.types import ToolCallRequest, hook_config
from langchain_core.messages import AIMessage, HumanMessage, RemoveMessage, ToolMessage
from langgraph.config import get_config, get_stream_writer
from langgraph.runtime import Runtime
from langgraph.types import Command, Overwrite


@dataclass
class SteeringCommand:
    command_id: str
    text: str
    cancel_tools: bool = False
    message: HumanMessage | None = None


@dataclass
class StreamSteering:
    """Loop-local control for one identified invocation; persistence belongs to hosts."""

    run_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    wake: asyncio.Event = field(default_factory=asyncio.Event)
    interrupt_tools: asyncio.Event = field(default_factory=asyncio.Event)
    phase: str = "llm_before"
    pending: SteeringCommand | None = None
    pending_queue: list[SteeringCommand] = field(default_factory=list)
    partial_text: str = ""
    command_status: dict[str, str] = field(default_factory=dict)
    command_fingerprints: dict[str, str] = field(default_factory=dict)
    active_tools: int = 0
    interrupted_model: bool = False

    def request(
        self,
        command_id: str,
        text: str,
        *,
        cancel_tools: bool = False,
        message: HumanMessage | None = None,
        queue_if_busy: bool = False,
    ) -> str:
        """Admit one immutable user message, preserving text-only caller compatibility."""
        prepared = (message or HumanMessage(content=text)).model_copy(update={"id": f"steer:{command_id}"}, deep=True)
        fingerprint = hashlib.sha256(
            json.dumps(
                {"text": text, "message": prepared.model_dump(mode="json"), "cancel_tools": cancel_tools},
                sort_keys=True,
                ensure_ascii=False,
            ).encode("utf-8")
        ).hexdigest()
        if command_id in self.command_status:
            same = self.command_fingerprints[command_id] == fingerprint
            return self.command_status[command_id] if same else "conflict"
        if self.phase in {"paused", "completed", "failed", "cancelled"}:
            return "inactive"
        if self.pending is not None and (not queue_if_busy or len(self.pending_queue) >= 9):
            return "busy"
        command = SteeringCommand(command_id=command_id, text=text, cancel_tools=cancel_tools, message=prepared)
        if self.pending is None:
            self.pending = command
        else:
            self.pending_queue.append(command)
        self.command_status[command_id] = "accepted"
        self.command_fingerprints[command_id] = fingerprint
        if cancel_tools:
            self.interrupt_tools.set()
        self.wake.set()
        return "accepted"

    def observe(self, chunk: Any) -> bool:
        """Capture public output and close admission on an approval pause."""
        if not isinstance(chunk, dict):
            return False
        if chunk.get("type") == "token":
            self.partial_text += str(chunk.get("content") or "")
        elif chunk.get("type") == "hitl_required":
            self.phase = "paused"
            return True
        return False

    def phase_event(self, thread_id: str) -> dict[str, Any]:
        return {"type": "run_phase", "run_id": self.run_id, "thread_id": thread_id, "phase": self.phase}


class LiveSteeringMiddleware(AgentMiddleware[Any, Any]):
    """Insert at a boundary, optionally interrupting admitted tool handlers.

    After-model updates jump back to the model so superseded tool calls never
    run. Requests admitted during tool execution are consumed by before-model
    once the tools superstep has completed. Explicit immediate insertion cancels
    tool handlers and supplies paired interruption results. The graph iterator
    is never cancelled or replayed by insertion.
    """

    def __init__(self, controls: dict[str, StreamSteering]) -> None:
        self.controls = controls
        self._interrupted_tools: set[asyncio.Future[Any]] = set()

    def _tool_done(self, task: asyncio.Future[Any]) -> None:
        self._interrupted_tools.discard(task)
        # A backend may ignore cancellation. Consume its eventual result/error;
        # it must never become a second tool result or update this checkpoint.
        with contextlib.suppress(asyncio.CancelledError, Exception):
            task.result()

    def _control(self) -> tuple[str, StreamSteering] | None:
        cfg = get_config().get("configurable") or {}
        thread_id = str(cfg.get("thread_id") or "")
        control = self.controls.get(thread_id)
        if control is None or cfg.get("harness_steering_run_id") != control.run_id:
            return None
        return thread_id, control

    @staticmethod
    def _emit(event: dict[str, Any]) -> None:
        get_stream_writer()({"__harness_steering__": event})

    def _phase(self, thread_id: str, control: StreamSteering, phase: str) -> None:
        control.phase = phase
        self._emit(control.phase_event(thread_id))

    def _apply(self, state: Any, control: StreamSteering, *, after_model: bool) -> dict[str, Any] | None:
        command = control.pending
        if command is None:
            return None
        boundary = control.phase
        updates: list[Any] = []
        messages = state.get("messages", [])
        last = messages[-1] if messages else None
        replace_message_state = False
        if after_model and isinstance(last, AIMessage):
            if last.tool_calls:
                if last.content:
                    updates.append(
                        last.model_copy(
                            update={
                                "tool_calls": [],
                                "invalid_tool_calls": [],
                                "additional_kwargs": {
                                    **{
                                        key: value
                                        for key, value in last.additional_kwargs.items()
                                        if key not in {"tool_calls", "function_call"}
                                    },
                                    "octop_interrupted": True,
                                },
                            }
                        )
                    )
                elif last.id:
                    updates.append(RemoveMessage(id=last.id))
                else:
                    # RemoveMessage requires an ID. Replacing the reducer state
                    # safely drops an id-less tail message before appending the
                    # steering input, so its stale tool calls cannot be replayed.
                    replace_message_state = True
            elif control.interrupted_model and not last.content and last.id:
                updates.append(RemoveMessage(id=last.id))
            elif control.interrupted_model and not last.content:
                replace_message_state = True
        commands = [command, *control.pending_queue]
        control.pending_queue.clear()
        control.pending = None
        control.wake.clear()
        control.interrupt_tools.clear()
        for index, command in enumerate(commands):
            message = command.message or HumanMessage(content=command.text, id=f"steer:{command.command_id}")
            updates.append(message)
            control.command_status[command.command_id] = "applied"
            self._emit(
                {
                    "type": "steering_applied",
                    "command_id": command.command_id,
                    "run_id": control.run_id,
                    "phase": boundary,
                    "partial_output_retained": index == 0 and bool(control.partial_text) and control.interrupted_model,
                }
            )
            self._emit(
                {
                    "type": "user",
                    "content": command.text,
                    "command_id": command.command_id,
                    "source": "dashboard_insert",
                    "run_id": control.run_id,
                    "inbound_attachments": deepcopy(message.additional_kwargs.get("octop_inbound_attachments", [])),
                }
            )
        control.interrupted_model = False
        result: dict[str, Any] = {
            "messages": Overwrite([*messages[:-1], *updates]) if replace_message_state else updates
        }
        if after_model:
            result["jump_to"] = "model"
        return result

    async def abefore_model(self, state: Any, runtime: Runtime[Any]) -> dict[str, Any] | None:
        active = self._control()
        if active is None:
            return None
        thread_id, control = active
        self._phase(thread_id, control, "llm_before")
        return self._apply(state, control, after_model=False)

    @hook_config(can_jump_to=["model"])
    async def aafter_model(self, state: Any, runtime: Runtime[Any]) -> dict[str, Any] | None:
        active = self._control()
        if active is None:
            return None
        thread_id, control = active
        messages = state.get("messages", [])
        last = messages[-1] if messages else None
        self._phase(thread_id, control, "tool_before" if getattr(last, "tool_calls", None) else "llm_after")
        return self._apply(state, control, after_model=True)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        active = self._control()
        if active is None:
            return await handler(request)
        thread_id, control = active
        control.partial_text = ""
        control.interrupted_model = False
        self._phase(thread_id, control, "llm_running")
        model_task = asyncio.ensure_future(handler(request))
        wake_task = asyncio.create_task(control.wake.wait())
        try:
            done, _ = await asyncio.wait({model_task, wake_task}, return_when=asyncio.FIRST_COMPLETED)
            if model_task in done:
                return await model_task
            model_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await model_task
            control.interrupted_model = True
            return ModelResponse(
                result=[
                    AIMessage(
                        content=control.partial_text,
                        additional_kwargs={"octop_partial": True, "octop_interrupted": True},
                    )
                ]
            )
        finally:
            for task in (model_task, wake_task):
                if not task.done():
                    task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        active = self._control()
        if active is None:
            return await handler(request)
        thread_id, control = active
        if control.pending is not None:
            return ToolMessage(
                content="Tool call superseded by a new user instruction before execution.",
                tool_call_id=request.tool_call["id"],
                name=request.tool_call["name"],
                additional_kwargs={"octop_superseded": True},
            )
        control.active_tools += 1
        self._phase(thread_id, control, "tool_running")
        tool_task = asyncio.ensure_future(handler(request))
        interrupt_task = asyncio.create_task(control.interrupt_tools.wait())
        cancel_requested = False
        try:
            done, _ = await asyncio.wait({tool_task, interrupt_task}, return_when=asyncio.FIRST_COMPLETED)
            if tool_task in done:
                return await tool_task
            self._phase(thread_id, control, "tool_interrupting")
            tool_task.cancel()
            cancel_requested = True
            # Bound cancellation cleanup: even a backend ignoring cancellation
            # must not keep the new user instruction behind a sleep/poll call.
            await asyncio.wait({tool_task}, timeout=0.1)
            return ToolMessage(
                content=(
                    "Tool call interrupted by the user to insert a new instruction. "
                    "Stopped waiting for this call; its result is unconfirmed. "
                    "An external or background operation may still be running. "
                    "Do not automatically retry or report that it was stopped."
                ),
                tool_call_id=request.tool_call["id"],
                name=request.tool_call["name"],
                status="error",
                additional_kwargs={"octop_interrupted": True},
            )
        finally:
            interrupt_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await interrupt_task
            if not tool_task.done() and not cancel_requested:
                tool_task.cancel()
            self._interrupted_tools.add(tool_task)
            tool_task.add_done_callback(self._tool_done)
            control.active_tools -= 1
            if not control.active_tools:
                self._phase(thread_id, control, "tool_after")


__all__ = ["LiveSteeringMiddleware", "SteeringCommand", "StreamSteering"]
