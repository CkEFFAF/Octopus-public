"""Public tool lifecycle observations correlated with a host run, without tool bodies."""

from __future__ import annotations

import asyncio
import hashlib
import json
import threading
import time
from collections.abc import Callable
from contextlib import suppress
from typing import Any
from urllib.parse import urlsplit, urlunsplit
from uuid import UUID, uuid4

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.outputs import LLMResult
from langgraph.config import get_config
from langgraph.types import Command

from octop_harness.middleware.native_task import native_task_association
from octop_harness.observability.request_snapshot import _redact

_SOURCE_TOOLS = frozenset(
    {"web_fetch", "tavily_search", "brave_search", "google_search", "kimi_search", "searchfree_search"}
)
_RESULT_CONTRACT_TOOLS = _SOURCE_TOOLS | {"ask_agent", "task", "browser_use"}


def _result_failed(name: str, output: Any, parsed: Any) -> bool:
    """Respect semantic error envelopes used by existing public tools.

    File contents may legitimately contain error-looking text. Interpret these
    envelopes only for tools whose result contracts define them as errors.
    """
    if getattr(output, "status", None) == "error":
        return True
    if name not in _RESULT_CONTRACT_TOOLS:
        return False
    content = getattr(output, "content", output)
    if isinstance(content, str) and content.lstrip().startswith("Error:"):
        return True
    return isinstance(parsed, dict) and (
        bool(parsed.get("error"))
        or parsed.get("success") is False
        or parsed.get("status") in {"error", "failed", "cancelled"}
    )


def _source_url(value: Any) -> str | None:
    if not isinstance(value, str) or len(value) > 4096:
        return None
    try:
        url = urlsplit(value)
        if url.scheme not in {"http", "https"} or not url.hostname or url.username or url.password:
            return None
        # Query strings can carry device/provider credentials. Retain the
        # retrieved resource identity without copying those values to history.
        return _redact(urlunsplit((url.scheme, url.netloc, url.path, "", "")))
    except ValueError:
        return None


def _dispatch_status(name: str, parsed: Any, status: str, values: dict[str, Any]) -> str:
    if name != "ask_agent" or not isinstance(parsed, dict):
        return status
    receipt = parsed.get("dispatch_receipt")
    if not isinstance(receipt, dict):
        return status
    for key in ("invocation_id", "task_outcome", "error_code", "retryable", "child_thread_id"):
        if key in receipt:
            values[key] = receipt[key]
    transport = receipt.get("transport_status")
    if transport == "running":
        return "accepted"
    return (
        transport
        if isinstance(transport, str) and transport in {"accepted", "completed", "failed", "cancelled", "unknown"}
        else status
    )


def _retrieved_urls(value: Any) -> list[str]:
    found: set[str] = set()
    pending = [value]
    for _ in range(200):
        if not pending or len(found) >= 20:
            break
        item = pending.pop()
        if isinstance(item, dict):
            for key, entry in list(item.items())[:30]:
                if key in {"url", "link", "source_url"} and (url := _source_url(entry)):
                    found.add(url)
                elif isinstance(entry, (list, dict)):
                    pending.append(entry)
        elif isinstance(item, list):
            pending.extend(item[:30])
    return sorted(found)


def _public_text(value: Any) -> str:
    """Only explicit text blocks; never stringify structured/private content."""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(
            block["text"]
            for block in value
            if isinstance(block, dict) and block.get("type") == "text" and isinstance(block.get("text"), str)
        )
    return ""


def _task_reply(output: Any) -> str:
    if isinstance(output, Command):
        update = output.update
        messages = update.get("messages", []) if isinstance(update, dict) else []
        return "\n".join(_public_text(message.content) for message in messages if isinstance(message, ToolMessage))
    return _public_text(getattr(output, "content", output))


class RunEventCallback(BaseCallbackHandler):
    """Send bounded tool/plan facts to a host; transport output remains separate."""

    def __init__(self, sink: Callable[[dict[str, Any]], None]) -> None:
        self.sink = sink
        self._pending: dict[UUID, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._parents: dict[UUID, UUID | None] = {}

    def on_chain_start(
        self, serialized: Any, inputs: Any, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any
    ) -> None:
        with self._lock:
            self._parents[run_id] = parent_run_id

    def on_chain_end(self, outputs: Any, *, run_id: UUID, **kwargs: Any) -> None:
        with self._lock:
            self._parents.pop(run_id, None)

    def on_chain_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        # Graph cancellation can bypass the tool's own error callback. Observe
        # only tasks proven to belong to the cancelled callback ancestry.
        if isinstance(error, asyncio.CancelledError):
            ancestor = self._native_parent(self._parents.get(run_id))
            affected = {UUID(ancestor["invocation_id"])} if ancestor else set()
            with self._lock:
                for identity, event in self._pending.items():
                    if event["payload"].get("source") != "native_subagent":
                        continue
                    parent = self._parents.get(identity)
                    seen = set()
                    while parent is not None and parent not in seen:
                        if parent == run_id:
                            affected.add(identity)
                            break
                        seen.add(parent)
                        parent = self._parents.get(parent)
            for identity in affected:
                self._finish(identity, "unknown", error_type="CancelledError", source_urls=[])
        self.on_chain_end(None, run_id=run_id)

    def _native_parent(self, parent: UUID | None) -> dict[str, Any]:
        with self._lock:
            seen = set()
            while parent is not None and parent not in seen:
                seen.add(parent)
                event = self._pending.get(parent)
                if event and event["payload"].get("source") == "native_subagent":
                    return {
                        key: event["payload"][key]
                        for key in ("invocation_id", "attempt_id", "task_id", "subagent_type")
                        if key in event["payload"]
                    }
                parent = self._parents.get(parent)
        return {}

    def on_llm_end(
        self, response: LLMResult, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any
    ) -> None:
        association = self._native_parent(parent_run_id)
        if not association:
            return
        text = "\n".join(
            _public_text(message.content)
            for batch in response.generations
            for generation in batch[:1]
            if isinstance((message := getattr(generation, "message", None)), AIMessage)
        )
        if not text:
            return
        text = _redact(text)
        identity = UUID(association["invocation_id"])
        with self._lock:
            event = self._pending.get(identity)
            if event is None:
                return
            event = {
                **event,
                "payload": {
                    **event["payload"],
                    "public_progress": text[:8192],
                    "public_progress_truncated": len(text) > 8192,
                    "public_truncated": event["payload"].get("public_truncated", False) or len(text) > 8192,
                },
            }
            self._pending[identity] = event
        self.sink(event)

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        inputs: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            cfg = get_config().get("configurable") or {}
        except RuntimeError:
            cfg = metadata or {}
        context = cfg.get("octop_execution_context") or {}
        values = inputs or {}
        name = _redact(str(serialized.get("name") or "tool"))[:200]
        payload: dict[str, Any] = {
            "name": name,
            "tool_run_id": str(run_id),
            "root_run_id": cfg.get("octop_task_run_id"),
        }
        if name != "task":
            payload.update(self._native_parent(kwargs.get("parent_run_id")))
        if name == "task":
            prompt = _redact(_public_text(values.get("description")))
            payload.update(
                source="native_subagent",
                invocation_id=str(run_id),
                attempt_id=str(uuid4()),
                public_prompt=prompt[:4096],
                public_prompt_truncated=len(prompt) > 4096,
                public_truncated=len(prompt) > 4096,
            )
            association = {**values, **(native_task_association.get() or {})}
            for key in ("task_id", "attempt"):
                if isinstance(association.get(key), str):
                    payload[key] = _redact(association[key])[:200]
        for key in ("file_path", "path", "cwd", "job_id", "expert", "subagent_type"):
            if isinstance(values.get(key), str):
                payload[key] = _redact(values[key])[:4096]
        if name == "write_todos" and isinstance(values.get("todos"), list):
            payload["todos"] = [
                {
                    "content": _redact(str(item.get("content") or ""))[:512],
                    "status": _redact(str(item.get("status") or ""))[:30],
                }
                for item in values["todos"][:32]
                if isinstance(item, dict)
            ]
            payload["truncated"] = len(values["todos"]) > 32
        path = str(values.get("file_path") or values.get("path") or "")
        plan_file = path.startswith("/.agent/plans/")
        if plan_file and isinstance(values.get("content"), str):
            payload["content_sha256"] = hashlib.sha256(values["content"].encode()).hexdigest()
        if name == "web_fetch" and (url := _source_url(values.get("url"))):
            payload["source_urls"] = [url]
        if name == "ask_agent":
            payload["background"] = values.get("mode") == "background" or cfg.get("peer_invoke_mode") == "async"
        event = {
            "event_id": f"tool:{run_id}",
            "run_id": cfg.get("octop_task_run_id"),
            "owner_user_id": cfg.get("user"),
            "thread_id": cfg.get("thread_id"),
            "turn_id": cfg.get("octop_turn_id"),
            "context_id": context.get("context_id"),
            "kind": "plan"
            if name == "write_todos" or plan_file
            else "dispatch"
            if name in {"ask_agent", "task"}
            else "tool",
            "status": "started",
            "created_at": time.time(),
            "payload": {
                **payload,
                "tool_call_id": kwargs.get("tool_call_id"),
                "parent_run_id": str(kwargs["parent_run_id"]) if kwargs.get("parent_run_id") else None,
            },
        }
        with self._lock:
            self._pending[run_id] = event
            self._parents[run_id] = kwargs.get("parent_run_id")
        self.sink(event)

    def on_tool_end(self, output: Any, *, run_id: UUID, **kwargs: Any) -> None:
        values = {"tool_call_id": output.tool_call_id} if getattr(output, "tool_call_id", None) else {}
        with self._lock:
            event = self._pending.get(run_id)
        content = getattr(output, "content", output)
        parsed: Any = content if isinstance(content, dict) else None
        if isinstance(content, str) and len(content) <= 256_000:
            with suppress(ValueError, TypeError):
                parsed = json.loads(content)
        name = event["payload"]["name"] if event else ""
        if event and name == "task":
            reply = _redact(_task_reply(output))
            values.update(
                public_reply=reply[:8192],
                public_reply_truncated=len(reply) > 8192,
                public_truncated=event["payload"].get("public_truncated", False) or len(reply) > 8192,
            )
        if isinstance(parsed, dict):
            for key in ("job_id", "context_id"):
                if isinstance(parsed.get(key), str) and 0 < len(parsed[key]) <= 200:
                    values[key] = _redact(parsed[key])
        status = "failed" if _result_failed(name, output, parsed) else "completed"
        if event and status == "completed":
            if event["payload"].get("background") or (
                event["kind"] == "dispatch" and isinstance(parsed, dict) and parsed.get("job_id")
            ):
                status = "accepted"
            if name in _SOURCE_TOOLS:
                urls = set(event["payload"].get("source_urls", [])) | set(_retrieved_urls(parsed))
                values["source_urls"] = sorted(urls)[:20]
        elif name in _SOURCE_TOOLS:
            values["source_urls"] = []
        self._finish(run_id, _dispatch_status(name, parsed, status, values), **values)

    def on_tool_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        self._finish(
            run_id,
            "unknown" if isinstance(error, asyncio.CancelledError) else "failed",
            error_type=type(error).__name__,
            source_urls=[],
        )

    def _finish(self, run_id: UUID, status: str, **values: Any) -> None:
        with self._lock:
            event = self._pending.pop(run_id, None)
            self._parents.pop(run_id, None)
        if event is not None:
            self.sink(
                {
                    **event,
                    "status": status,
                    "payload": {
                        **event["payload"],
                        **values,
                        "duration_ms": (time.time() - event["created_at"]) * 1000,
                    },
                }
            )


__all__ = ["RunEventCallback"]
