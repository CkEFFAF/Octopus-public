"""Fetch limits apply while reading decoded streams, including redirects."""

from __future__ import annotations

import gzip
import importlib
import tracemalloc
import zlib
from collections.abc import Iterator

import httpx
import pytest

fetch = importlib.import_module("octop_harness.builtin.tools.web_fetch")


class Body(httpx.SyncByteStream):
    def __init__(self, chunks: list[bytes]) -> None:
        self.chunks = chunks
        self.read = 0
        self.closed = False

    def __iter__(self) -> Iterator[bytes]:
        for chunk in self.chunks:
            self.read += 1
            yield chunk

    def close(self) -> None:
        self.closed = True


@pytest.mark.parametrize("compressed", [False, True])
def test_fetch_stops_on_decoded_body_limit(monkeypatch: pytest.MonkeyPatch, compressed: bool) -> None:
    limit = 1024
    monkeypatch.setattr(fetch, "_MAX_BYTES", limit)
    monkeypatch.setattr(fetch, "validate_agent_fetch_url", lambda url: url)
    first = gzip.compress(b"x" * (limit + 1)) if compressed else b"x" * (limit + 1)
    body = Body([first, b"must not be read"])
    headers = {"content-encoding": "gzip"} if compressed else {}
    transport = httpx.MockTransport(lambda request: httpx.Response(200, headers=headers, stream=body))
    client_type = httpx.Client
    monkeypatch.setattr(fetch.httpx, "Client", lambda **kw: client_type(transport=transport, **kw))
    result = fetch.web_fetch.invoke({"url": "https://example.test"})
    assert result.startswith("Error:") and "exceeding" in result
    assert body.read == 1
    assert body.closed


def test_redirect_body_is_closed_without_reading(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(fetch, "validate_agent_fetch_url", lambda url: url)
    redirect_body = Body([b"never read"])
    success_body = Body([b"done"])

    def response(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/first":
            return httpx.Response(302, headers={"location": "/last"}, stream=redirect_body)
        return httpx.Response(200, stream=success_body)

    client_type = httpx.Client
    transport = httpx.MockTransport(response)
    monkeypatch.setattr(fetch.httpx, "Client", lambda **kw: client_type(transport=transport, **kw))
    assert fetch.web_fetch.invoke({"url": "https://example.test/first"}) == "done"
    assert redirect_body.read == 0
    assert redirect_body.closed and success_body.closed


def test_compressed_body_at_limit_is_decoded_once(monkeypatch: pytest.MonkeyPatch) -> None:
    content = "你好".encode()
    monkeypatch.setattr(fetch, "_MAX_BYTES", len(content))
    monkeypatch.setattr(fetch, "validate_agent_fetch_url", lambda url: url)
    body = Body([gzip.compress(content)])
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            200,
            headers={"content-encoding": "gzip", "content-type": "text/plain; charset=utf-8"},
            stream=body,
        )
    )
    client_type = httpx.Client
    monkeypatch.setattr(fetch.httpx, "Client", lambda **kw: client_type(transport=transport, **kw))
    assert fetch.web_fetch.invoke({"url": "https://example.test"}) == "你好"
    assert body.closed


def test_single_gzip_chunk_cannot_allocate_the_full_expansion(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(fetch, "_MAX_BYTES", 1024)
    body = Body([gzip.compress(b"x" * (24 * 1024 * 1024))])
    response = httpx.Response(200, headers={"content-encoding": "gzip"}, stream=body)
    tracemalloc.start()
    try:
        with pytest.raises(fetch.FetchResponseTooLargeError):
            fetch._read_limited_body(response)
        _, peak = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
        response.close()
    assert peak < 4 * 1024 * 1024


@pytest.mark.parametrize("raw", [True, False])
def test_deflate_decodes_across_header_chunks(monkeypatch: pytest.MonkeyPatch, raw: bool) -> None:
    monkeypatch.setattr(fetch, "_MAX_BYTES", 32)
    encoder = zlib.compressobj(wbits=-zlib.MAX_WBITS if raw else zlib.MAX_WBITS)
    payload = encoder.compress(b"hello") + encoder.flush()
    body = Body([bytes([byte]) for byte in payload])
    response = httpx.Response(200, headers={"content-encoding": "deflate"}, stream=body)
    try:
        assert fetch._read_limited_body(response) == b"hello"
    finally:
        response.close()


@pytest.mark.parametrize("encoding,payload", [("gzip", b"bad"), ("deflate", b"x"), ("br", b"unknown")])
def test_invalid_or_unsupported_encoding_is_recoverable(encoding: str, payload: bytes) -> None:
    response = httpx.Response(200, headers={"content-encoding": encoding}, stream=Body([payload]))
    try:
        with pytest.raises(httpx.DecodingError):
            fetch._read_limited_body(response)
    finally:
        response.close()


@pytest.mark.parametrize("same_chunk", [True, False])
def test_compressed_trailing_data_cannot_accumulate(same_chunk: bool) -> None:
    compressed = gzip.compress(b"hello")
    chunks = [compressed + b"junk"] if same_chunk else [compressed, b"junk", b"not read"]
    body = Body(chunks)
    response = httpx.Response(200, headers={"content-encoding": "gzip"}, stream=body)
    try:
        with pytest.raises(httpx.DecodingError, match="Unexpected data"):
            fetch._read_limited_body(response)
        assert body.read <= 2
    finally:
        response.close()
