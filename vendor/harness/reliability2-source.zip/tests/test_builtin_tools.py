"""Tests for built-in tools."""

from __future__ import annotations

import importlib
import re

import httpx
import pytest

from octop_harness.builtin.tools.current_time import CurrentTimeTool, current_time
from octop_harness.builtin.tools.web_fetch import web_fetch

_WEEKDAYS_EN = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}
_WEEKDAYS_ZH = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"}
# ``YYYY-MM-DD HH:MM:SS <tzname> (UTC±HHMM) <Weekday> (<localized weekday>)``
_TS_RE = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2}) (?P<time>\d{2}:\d{2}:\d{2}) "
    r"(?P<tzname>\S+) \(UTC(?P<offset>[+-]\d{4})\) "
    r"(?P<wd_en>[A-Z][a-z]+) \((?P<wd_zh>[\u4e00-\u9fff]+)\)$",
)


class TestCurrentTime:
    def test_default_returns_human_readable_with_weekday(self) -> None:
        result = current_time.invoke({})
        assert isinstance(result, str)
        match = _TS_RE.match(result)
        assert match is not None, f"unexpected format: {result!r}"
        assert match["wd_en"] in _WEEKDAYS_EN
        assert match["wd_zh"] in _WEEKDAYS_ZH

    def test_explicit_utc_timezone(self) -> None:
        result = current_time.invoke({"tz": "UTC"})
        match = _TS_RE.match(result)
        assert match is not None, result
        assert match["offset"] == "+0000"
        assert match["tzname"] == "UTC"

    def test_named_timezone_shanghai(self) -> None:
        result = current_time.invoke({"tz": "Asia/Shanghai"})
        match = _TS_RE.match(result)
        assert match is not None, result
        # CST is +08:00; offset in the rendered string must agree.
        assert match["offset"] == "+0800"

    def test_weekday_consistency(self) -> None:
        """English & Chinese weekday must always agree (same index)."""
        order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        zh_order = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        result = current_time.invoke({"tz": "UTC"})
        match = _TS_RE.match(result)
        assert match is not None
        assert order.index(match["wd_en"]) == zh_order.index(match["wd_zh"])

    def test_unknown_timezone_returns_error(self) -> None:
        result = current_time.invoke({"tz": "Mars/Olympus"})
        assert isinstance(result, str)
        assert result.startswith("Error:")
        assert "Unknown timezone" in result
        assert "Mars/Olympus" in result

    def test_default_timezone_when_tz_omitted(self) -> None:
        tool = CurrentTimeTool("Asia/Shanghai").as_tool()
        result = tool.invoke({})
        match = _TS_RE.match(result)
        assert match is not None, result
        assert match["offset"] == "+0800"


class TestWebFetch:
    def test_rejects_non_http_url(self) -> None:
        result = web_fetch.invoke({"url": "ftp://example.com"})
        assert result.startswith("Error:") and "ftp://" in result

    @pytest.mark.parametrize(
        ("status", "headers", "body", "expected"),
        [
            (200, {}, b"x" * (5 * 1024 * 1024 + 1), "exceeding"),
            (
                200,
                {"content-type": "text/html; charset=utf-8"},
                b"<h1>Title</h1><p>Hello <b>world</b></p>",
                "Hello **world**",
            ),
            (404, {}, b"not found", "Error: HTTP 404 Not Found for https://example.com/"),
        ],
        ids=["oversize", "html", "http_error"],
    )
    def test_response(
        self, monkeypatch: pytest.MonkeyPatch, status: int, headers: dict[str, str], body: bytes, expected: str
    ) -> None:
        mod = importlib.import_module("octop_harness.builtin.tools.web_fetch")
        client_type = httpx.Client
        transport = httpx.MockTransport(
            lambda request: httpx.Response(status, headers=headers, stream=httpx.ByteStream(body))
        )
        monkeypatch.setattr(mod, "validate_agent_fetch_url", lambda url: url)
        monkeypatch.setattr(mod.httpx, "Client", lambda **kw: client_type(transport=transport, **kw))
        assert expected in web_fetch.invoke({"url": "https://example.com/"})

    def test_network_error_returned_as_string(self, monkeypatch: pytest.MonkeyPatch) -> None:
        mod = importlib.import_module("octop_harness.builtin.tools.web_fetch")

        def fail(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("Name or service not known", request=request)

        client_type = httpx.Client
        transport = httpx.MockTransport(fail)
        monkeypatch.setattr(mod, "validate_agent_fetch_url", lambda url: url)
        monkeypatch.setattr(mod.httpx, "Client", lambda **kw: client_type(transport=transport, **kw))
        result = web_fetch.invoke({"url": "https://no-such-host.invalid/"})
        assert result.startswith("Error: ConnectError")
