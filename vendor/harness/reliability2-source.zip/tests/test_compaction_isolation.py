"""Forced compaction isolates mutable policy and counts the full request context."""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from deepagents.middleware.summarization import SummarizationMiddleware
from langchain_core.messages import HumanMessage
from tests.test_compaction import _long_thread, _summary_model, _workspace_backend

from octop_harness.compaction import FORCE_KEEP_MESSAGES, _persist_compact_event, force_compact_thread
from octop_harness.context_usage import conversation_tokens_from_messages, estimate_tokens
from octop_harness.middleware.memory_recall import (
    replay_context_snapshots,
    replay_recall_snapshots,
    stamp_context_snapshot,
    stamp_recall_snapshot,
)


@pytest.mark.asyncio
async def test_parallel_force_compactions_keep_models_and_graph_policy_isolated(tmp_path) -> None:
    backend = _workspace_backend(tmp_path)
    original_model = _summary_model("original")
    models = {"A": _summary_model("summary A"), "B": _summary_model("summary B")}
    graph_mw = SummarizationMiddleware(
        model=original_model,
        backend=backend,
        trigger=("tokens", 100_000),
        keep=("messages", 20),
        summary_prompt="custom summary: {messages}",
        trim_tokens_to_summarize=1234,
    )
    helper = graph_mw._lc_helper
    original_summary_model = helper._summary_model
    messages = _long_thread(8)
    graph = MagicMock()
    graph.aget_state = AsyncMock(
        side_effect=lambda config: SimpleNamespace(
            values={
                "messages": messages,
                "_summarization_session_id": f"session_{config['configurable']['thread_id']}",
            }
        )
    )
    graph.aupdate_state = AsyncMock()
    started = {name: asyncio.Event() for name in models}
    release = {name: asyncio.Event() for name in models}
    seen = {}
    offloads = []

    async def summarize(mw, _messages):
        name = next(name for name, model in models.items() if mw.model is model)
        started[name].set()
        await release[name].wait()
        seen[name] = (
            mw.model,
            mw._lc_helper.keep,
            mw._lc_helper.summary_prompt,
            mw._lc_helper.trim_tokens_to_summarize,
        )
        return f"summary {name}"

    async def offload(_mw, target, _messages, session_id):
        offloads.append((target, session_id))
        return f"/conversation_history/{session_id}.md"

    with (
        patch.object(SummarizationMiddleware, "_acreate_summary", summarize),
        patch.object(SummarizationMiddleware, "_aoffload_to_backend", offload),
    ):
        tasks = {}
        try:
            for name, model in models.items():
                tasks[name] = asyncio.create_task(
                    force_compact_thread(
                        graph=graph,
                        backend=MagicMock(),
                        model=model,
                        thread_id=name,
                        summarization_middleware=graph_mw,
                    )
                )
                await asyncio.wait_for(started[name].wait(), 2)
            observed_graph_policy = (helper.model, helper.keep, helper._summary_model)
            release["A"].set()
            assert (await tasks["A"]).ok
            release["B"].set()
            assert (await tasks["B"]).ok
        finally:
            for signal in release.values():
                signal.set()
            await asyncio.gather(*tasks.values(), return_exceptions=True)

    assert observed_graph_policy == (original_model, ("messages", 20), original_summary_model)
    assert helper.model is original_model
    assert helper.keep == ("messages", 20)
    assert helper._summary_model is original_summary_model
    for name, model in models.items():
        assert seen[name] == (model, ("messages", FORCE_KEEP_MESSAGES), "custom summary: {messages}", 1234)
    assert offloads == [(backend, "session_A"), (backend, "session_B")]


@pytest.mark.asyncio
async def test_force_compaction_estimates_replay_host_and_recall_snapshots() -> None:
    removed = stamp_context_snapshot(HumanMessage(content="first", id="a"), "device", "device context " * 500)
    removed = stamp_recall_snapshot(removed, "remember this " * 500)
    preserved = stamp_context_snapshot(HumanMessage(content="recent", id="b"), "task", "task context " * 500)
    summary = HumanMessage(content="summary", additional_kwargs={"lc_source": "summarization"})
    graph = SimpleNamespace(aupdate_state=AsyncMock())
    mw = SimpleNamespace(
        _build_new_messages_with_path=lambda *_: [summary],
        _compute_state_cutoff=lambda _event, cutoff: cutoff,
    )
    result = await _persist_compact_event(
        graph=graph,
        config={},
        work_mw=mw,
        event=None,
        cutoff=1,
        file_path="history.md",
        summary="summary",
        session_id="session",
        to_summarize=[removed],
        preserved=[preserved],
        thread_id="thread",
    )

    def expected(messages):
        return conversation_tokens_from_messages(
            replay_context_snapshots(replay_recall_snapshots(messages), originals=messages)
        )

    assert result.ok
    assert result.before_estimated_tokens == expected([removed, preserved])
    assert result.after_estimated_tokens == expected([summary, preserved])
    assert result.removed_tokens == expected([removed]) - estimate_tokens("summary")
    assert removed.content == "first"
    assert preserved.content == "recent"
