"""Memory capture follows graph state across concurrent and resumed calls."""

from __future__ import annotations

import asyncio
import operator
from typing import Annotated, Any, TypedDict
from unittest.mock import MagicMock

import pytest
from langchain.agents import create_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph

from octop_harness.middleware.memory import MemoryMiddleware


class GatedModel(FakeMessagesListChatModel):
    entered: dict[str, Any] = {}
    released: dict[str, Any] = {}

    async def _agenerate(self, messages: Any, **kwargs: Any) -> ChatResult:
        prompt = str(messages[-1].content)
        self.entered[prompt].set()
        await self.released[prompt].wait()
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=f"reply to {prompt}"))])


def _model(*prompts: str) -> GatedModel:
    return GatedModel(
        responses=[],
        entered={prompt: asyncio.Event() for prompt in prompts},
        released={prompt: asyncio.Event() for prompt in prompts},
    )


def _middleware() -> tuple[MemoryMiddleware, MagicMock]:
    mw = MemoryMiddleware(service=MagicMock(), recall_inject_enabled=False, jsonl_enabled=False)
    capture = MagicMock()
    mw._submit_capture = capture
    return mw, capture


async def _entered(model: GatedModel, *prompts: str) -> None:
    await asyncio.wait_for(asyncio.gather(*(model.entered[prompt].wait() for prompt in prompts)), 2)


@pytest.mark.asyncio
async def test_parallel_threads_capture_only_each_new_exchange() -> None:
    mw, capture = _middleware()
    model = _model("A", "B")
    graph = create_agent(model, middleware=[mw], checkpointer=InMemorySaver())
    a = asyncio.create_task(graph.ainvoke({"messages": [HumanMessage("A")]}, {"configurable": {"thread_id": "a"}}))
    b = asyncio.create_task(
        graph.ainvoke(
            {"messages": [HumanMessage("old"), AIMessage("old reply"), HumanMessage("B")]},
            {"configurable": {"thread_id": "b"}},
        )
    )
    try:
        await _entered(model, "A", "B")
        model.released["A"].set()
        result = await a
        assert "_harness_memory_cursor" not in result
        assert (await graph.aget_state({"configurable": {"thread_id": "a"}})).values["_harness_memory_cursor"] is None
        model.released["B"].set()
        await b
    finally:
        a.cancel()
        b.cancel()
        await asyncio.gather(a, b, return_exceptions=True)
    assert [(call.args[0][0].content, call.args[0][-1].content) for call in capture.call_args_list] == [
        ("A", "reply to A"),
        ("B", "reply to B"),
    ]


class ParentState(TypedDict):
    replies: Annotated[list[str], operator.add]


@pytest.mark.asyncio
async def test_parallel_subgraphs_share_middleware_without_sharing_cursor() -> None:
    mw, capture = _middleware()
    model = _model("A", "B")
    child = create_agent(model, middleware=[mw])
    a_finished = asyncio.Event()

    async def branch_a(state: ParentState) -> ParentState:
        result = await child.ainvoke({"messages": [HumanMessage("A")]})
        a_finished.set()
        return {"replies": [result["messages"][-1].content]}

    async def branch_b(state: ParentState) -> ParentState:
        result = await child.ainvoke({"messages": [HumanMessage("old"), AIMessage("old reply"), HumanMessage("B")]})
        return {"replies": [result["messages"][-1].content]}

    builder = StateGraph(ParentState)
    builder.add_node("a", branch_a)
    builder.add_node("b", branch_b)
    builder.add_edge(START, "a")
    builder.add_edge(START, "b")
    builder.add_edge("a", END)
    builder.add_edge("b", END)
    graph = builder.compile(checkpointer=InMemorySaver())
    task = asyncio.create_task(graph.ainvoke({"replies": []}, {"configurable": {"thread_id": "parent"}}))
    try:
        await _entered(model, "A", "B")
        model.released["A"].set()
        await asyncio.wait_for(a_finished.wait(), 2)
        model.released["B"].set()
        assert set((await task)["replies"]) == {"reply to A", "reply to B"}
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
    assert sorted((call.args[0][0].content, call.args[0][-1].content) for call in capture.call_args_list) == [
        ("A", "reply to A"),
        ("B", "reply to B"),
    ]


@pytest.mark.asyncio
async def test_cancelled_model_resumes_capture_in_fresh_middleware() -> None:
    saver = InMemorySaver()
    mw, cancelled_capture = _middleware()
    model = _model("retry")
    graph = create_agent(model, middleware=[mw], checkpointer=saver)
    config = {"configurable": {"thread_id": "cancelled"}}
    task = asyncio.create_task(
        graph.ainvoke({"messages": [HumanMessage("old"), AIMessage("old reply"), HumanMessage("retry")]}, config)
    )
    try:
        await _entered(model, "retry")
    finally:
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
    cancelled_capture.assert_not_called()
    resumed_mw, resumed_capture = _middleware()
    resumed_model = _model("retry")
    resumed_model.released["retry"].set()
    restarted = create_agent(resumed_model, middleware=[resumed_mw], checkpointer=saver)
    await restarted.ainvoke(None, config)
    resumed_capture.assert_called_once()
    assert [message.content for message in resumed_capture.call_args.args[0]] == ["retry", "reply to retry"]


@pytest.mark.asyncio
async def test_recall_failure_preserves_capture_boundary_in_real_graph() -> None:
    service = MagicMock()
    service.recall.side_effect = RuntimeError("recall storage unavailable")
    mw = MemoryMiddleware(service=service, jsonl_enabled=False)
    capture = MagicMock()
    mw._submit_capture = capture
    model = _model("current")
    model.released["current"].set()
    graph = create_agent(model, middleware=[mw], checkpointer=InMemorySaver())
    result = await graph.ainvoke(
        {"messages": [HumanMessage("old"), AIMessage("old reply"), HumanMessage("current")]},
        {"configurable": {"thread_id": "recall-failed"}},
    )
    service.recall.assert_called_once()
    assert result["messages"][-1].content == "reply to current"
    capture.assert_called_once()
    assert [message.content for message in capture.call_args.args[0]] == ["current", "reply to current"]
