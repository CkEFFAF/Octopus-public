"""MCP schemas and argument identities survive LangChain's tool boundary."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import pytest
from langchain_core.tools import StructuredTool
from langchain_core.utils.function_calling import convert_to_openai_tool

from octop_harness.mcp import _postprocess_mcp_tools, mcp_args_model


def _schema() -> dict[str, Any]:
    return {
        "type": "object",
        "$defs": {"Row": {"type": "object", "properties": {"id": {"type": "integer", "minimum": 1}}}},
        "properties": {
            "_client_info": {"$ref": "#/$defs/Row"},
            "items": {"type": "array", "items": {"$ref": "#/$defs/Row"}, "minItems": 1},
            "schema": {"anyOf": [{"type": "string", "enum": ["one", "two"]}, {"type": "null"}]},
            "optional": {"type": "string"},
            "nullable": {"type": ["string", "null"]},
        },
        "required": ["_client_info", "items", "schema"],
        "additionalProperties": False,
    }


def _tool(name: str, schema: dict[str, Any]) -> StructuredTool:
    async def run(**arguments: Any) -> dict[str, Any]:
        return arguments

    return StructuredTool(name=name, description="Test MCP tool", args_schema=schema, coroutine=run)


def test_public_schema_helper_preserves_schema_without_mutating_input() -> None:
    schema = _schema()
    preserved = mcp_args_model("svc_complex", schema)
    assert preserved == schema
    assert preserved is not schema
    preserved["properties"]["items"]["minItems"] = 5
    assert schema["properties"]["items"]["minItems"] == 1


def test_public_argument_preparation_retains_unknown_and_nullable_values() -> None:
    from octop_harness import prepare_mcp_tool_arguments

    schema = {
        "type": "object",
        "properties": {
            "number": {"type": "number"},
            "optional_nullable": {"anyOf": [{"type": "number"}, {"type": "null"}]},
            "required_nullable": {"type": ["number", "null"]},
        },
        "required": ["required_nullable"],
    }
    arguments = {"number": None, "optional_nullable": None, "required_nullable": None, "unknown": None}
    assert prepare_mcp_tool_arguments(arguments, schema) == {
        "optional_nullable": None,
        "required_nullable": None,
        "unknown": None,
    }
    assert arguments["number"] is None


@pytest.mark.asyncio
async def test_remote_tool_preserves_complex_schema_and_explicit_nullable_arguments() -> None:
    schema = _schema()
    original = deepcopy(schema)
    tool = _tool("svc.complex", schema)
    _postprocess_mcp_tools([tool], server_name="svc", tool_arg_aliases={})
    assert tool.args_schema == original
    bound = convert_to_openai_tool(tool)["function"]["parameters"]
    assert bound["properties"]["items"]["type"] == "array"
    assert bound["properties"]["_client_info"]["type"] == "object"
    assert bound["additionalProperties"] is False
    assert bound["properties"]["schema"]["anyOf"][0]["enum"] == ["one", "two"]
    arguments = {"_client_info": {"id": 2}, "items": [{"id": 3}], "schema": None, "nullable": None}
    assert await tool.ainvoke(arguments) == arguments
    assert await tool.ainvoke({**arguments, "optional": None}) == arguments
    assert schema == original


@pytest.mark.asyncio
async def test_nullable_reference_and_alias_are_preserved_before_mcp_call() -> None:
    schema = {
        "type": "object",
        "$defs": {"Nullable": {"oneOf": [{"type": "integer"}, {"type": "null"}]}},
        "properties": {"canonical": {"$ref": "#/$defs/Nullable"}, "optional": {"type": "number"}},
        "required": ["canonical"],
    }
    tool = _tool("svc_write", schema)
    _postprocess_mcp_tools([tool], server_name="svc", tool_arg_aliases={"write": {"alias": "canonical"}})
    assert await tool.ainvoke({"alias": None, "optional": None}) == {"canonical": None}
    assert await tool.ainvoke({"alias": 1}) == {"canonical": 1}
    assert await tool.ainvoke({"canonical": None, "alias": 2}) == {"canonical": None}


@pytest.mark.parametrize("reverse", [False, True])
def test_name_collision_assignment_is_unique_and_independent_of_input_order(reverse: bool) -> None:
    names = ["svc.a", "svc_a", "svc a", "svc_a_2"]
    tools = [_tool(name, {"type": "object", "properties": {}}) for name in reversed(names) if reverse]
    if not reverse:
        tools = [_tool(name, {"type": "object", "properties": {}}) for name in names]
    original_names = [tool.name for tool in tools]
    _postprocess_mcp_tools(tools, server_name="svc", tool_arg_aliases={})
    assigned = dict(zip(original_names, [tool.name for tool in tools], strict=True))
    assert len(set(assigned.values())) == len(names)
    assert assigned == {"svc.a": "svc_a_4", "svc_a": "svc_a", "svc a": "svc_a_3", "svc_a_2": "svc_a_2"}


@pytest.mark.asyncio
async def test_sanitized_names_keep_the_original_tool_callable() -> None:
    def tool(name: str) -> StructuredTool:
        async def run(**_: Any) -> str:
            return name

        return StructuredTool(name=name, description="MCP", args_schema={"type": "object"}, coroutine=run)

    tools = [tool("svc.a"), tool("svc_a")]
    _postprocess_mcp_tools(tools, server_name="svc", tool_arg_aliases={})
    assert {item.name: await item.ainvoke({}) for item in tools} == {"svc_a_2": "svc.a", "svc_a": "svc_a"}
