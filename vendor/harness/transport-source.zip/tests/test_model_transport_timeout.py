"""Model requests retain finite transport waits with or without session headers."""

from __future__ import annotations

import asyncio
import json

import httpx
import pytest

from octop_harness.config import ModelConfig, ProviderConfig
from octop_harness.llm import factory
from octop_harness.llm.factory import build_chat_model
from octop_harness.llm.session_header import aclose_session_http_clients


@pytest.mark.asyncio
@pytest.mark.parametrize("protocol,model_id", [("openai", "deepseek"), ("anthropic", "claude-sonnet-4")])
@pytest.mark.parametrize("session_header", [None, "x-session"])
async def test_model_clients_have_finite_transport_timeouts(
    protocol: str, model_id: str, session_header: str | None
) -> None:
    model = build_chat_model(
        ProviderConfig(
            id="test",
            protocol=protocol,
            base_url="https://example.com/v1",
            api_key="test-key",
            session_header=session_header,
        ),
        ModelConfig(id=model_id),
    )
    try:
        client = model.root_async_client if protocol == "openai" else model._async_client
        expected = httpx.Timeout(300.0, connect=30.0, pool=30.0)
        assert client.timeout == (expected if protocol == "openai" else 300.0)
        assert client.max_retries == 1
        if session_header:
            assert client._client.timeout == expected
    finally:
        await aclose_session_http_clients(model)


@pytest.mark.asyncio
async def test_active_stream_can_exceed_the_transport_idle_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(factory, "MODEL_REQUEST_TIMEOUT", httpx.Timeout(0.25))

    async def streaming(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            await reader.readuntil(b"\r\n\r\n")
            writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nConnection: close\r\n\r\n")
            for _ in range(8):
                payload = {"id": "test", "choices": [{"index": 0, "delta": {"content": "x"}, "finish_reason": None}]}
                writer.write(f"data: {json.dumps(payload)}\n\n".encode())
                await writer.drain()
                await asyncio.sleep(0.05)
            writer.write(b"data: [DONE]\n\n")
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(streaming, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    model = build_chat_model(
        ProviderConfig(id="test", api_key="test-key", base_url=f"http://127.0.0.1:{port}/v1"),
        ModelConfig(id="deepseek"),
    )
    try:
        async with asyncio.timeout(5):
            chunks = [chunk async for chunk in model.astream("ping")]
        assert "".join(str(chunk.content) for chunk in chunks) == "xxxxxxxx"
    finally:
        server.close()
        await server.wait_closed()


@pytest.mark.asyncio
@pytest.mark.parametrize("session_header", [None, "x-session"])
async def test_silent_openai_server_times_out_before_a_first_chunk(
    monkeypatch: pytest.MonkeyPatch, session_header: str | None
) -> None:
    from openai import APITimeoutError

    from octop_harness.llm import session_header as session_clients

    timeout = httpx.Timeout(0.05)
    monkeypatch.setattr(factory, "MODEL_REQUEST_TIMEOUT", timeout)
    monkeypatch.setattr(session_clients, "MODEL_REQUEST_TIMEOUT", timeout)
    writers: list[asyncio.StreamWriter] = []

    async def silent(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        writers.append(writer)
        try:
            await reader.read()
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(silent, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    model = build_chat_model(
        ProviderConfig(
            id="test", api_key="test-key", base_url=f"http://127.0.0.1:{port}/v1", session_header=session_header
        ),
        ModelConfig(id="deepseek"),
    )
    try:
        # A real silent TCP peer reproduces a missing first response. MockTransport
        # alone would not enforce httpx read timeouts.
        with pytest.raises(APITimeoutError):
            async with asyncio.timeout(5):
                async for _ in model.astream("ping"):
                    pytest.fail("the silent peer cannot produce a model chunk")
    finally:
        server.close()
        await server.wait_closed()
        for writer in writers:
            writer.close()
        await asyncio.gather(*(writer.wait_closed() for writer in writers), return_exceptions=True)
        await aclose_session_http_clients(model)
