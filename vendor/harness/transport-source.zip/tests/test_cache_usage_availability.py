from types import SimpleNamespace

from octop_harness.context_usage import extract_usage_from_message
from octop_harness.protocols.langgraph import _usage_event
from octop_harness.usage import normalize_usage_metadata


def test_unknown_survives_canonical_normalization_and_stream_event():
    raw = {"input_tokens": 100, "output_tokens": 3}
    first = normalize_usage_metadata(raw)
    assert first["cache_metrics_reported"] is False
    assert normalize_usage_metadata(first)["cache_metrics_reported"] is False
    message = SimpleNamespace(id="call", usage_metadata=raw, response_metadata={})
    assert extract_usage_from_message(message)["cache_metrics_reported"] is False
    assert _usage_event(message, {}, "model")["usage"]["cache_metrics_reported"] is False


def test_explicit_zero_is_reported_but_cache_writes_do_not_imply_read_counts():
    assert normalize_usage_metadata({"input_tokens": 100, "cache_read_tokens": 0})["cache_metrics_reported"] is True
    assert (
        normalize_usage_metadata({"input_tokens": 100, "input_token_details": {"cache_read": 0}})[
            "cache_metrics_reported"
        ]
        is True
    )
    assert (
        normalize_usage_metadata({"input_tokens": 100, "prompt_cache_hit_tokens": 80})["cache_metrics_reported"] is True
    )
    assert normalize_usage_metadata({"input_tokens": 100, "cache_write_tokens": 10})["cache_metrics_reported"] is False
