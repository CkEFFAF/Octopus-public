from copy import deepcopy

from langchain_core.messages import HumanMessage
from langchain_core.messages.utils import count_tokens_approximately

from octop_harness.middleware.memory_recall import (
    CONTEXT_SNAPSHOTS_KEY,
    count_tokens_with_recall,
    replay_context_snapshots,
    replay_recall_snapshots,
    stamp_context_snapshot,
    stamp_recall_snapshot,
)
from octop_harness.observability.sources import _sources, message_parts, request_sources


def test_host_contexts_and_memory_are_counted_once_and_replay_after_edit():
    original = HumanMessage("Original request", id="human")
    memory = stamp_recall_snapshot(original, "Recalled fact " * 100)
    stamped = stamp_context_snapshot(memory, "brief", "\nDerived brief " * 200)
    stamped = stamp_context_snapshot(stamped, "workflow", "\nWorkflow state " * 80)
    before = deepcopy(stamped)
    replayed = replay_context_snapshots(replay_recall_snapshots([stamped]), originals=[stamped])
    assert count_tokens_with_recall([stamped]) == count_tokens_approximately(replayed)
    assert count_tokens_with_recall([stamped]) > count_tokens_approximately([stamped]) + 500
    assert stamped == before
    assert CONTEXT_SNAPSHOTS_KEY not in replayed[0].additional_kwargs
    edited = stamped.model_copy(update={"content": "Changed request"})
    assert (
        replay_context_snapshots(replay_recall_snapshots([edited]), originals=[edited])[0].content == "Changed request"
    )


def test_namespace_replay_matches_budget_and_retains_image_and_recall():
    original = HumanMessage(
        [{"type": "image_url", "image_url": {"url": "https://example.invalid/image.png"}}], id="image"
    )
    stamped = stamp_context_snapshot(stamp_recall_snapshot(original, "Recalled"), "brief", "\nBrief")
    stamped = stamp_context_snapshot(stamped, "workflow", "\nWorkflow")
    first = replay_context_snapshots(replay_recall_snapshots([stamped]), originals=[stamped], namespace="brief")
    second = replay_context_snapshots(first, originals=[stamped], namespace="workflow")
    all_at_once = replay_context_snapshots(replay_recall_snapshots([stamped]), originals=[stamped])
    assert second == all_at_once
    second[0].content[0]["image_url"]["url"] = "adapter mutation"
    assert stamped.content[0]["image_url"]["url"] == "https://example.invalid/image.png"


def test_request_snapshot_attributes_host_context_to_the_correct_message():
    from types import SimpleNamespace

    a = stamp_context_snapshot(HumanMessage("First", id="first"), "brief", "\nBrief first")
    b = stamp_context_snapshot(HumanMessage("Second", id="second"), "brief", "\nBrief second")
    token = request_sources.set(_sources(SimpleNamespace(state={"messages": [a, b]})))
    try:
        messages = replay_context_snapshots([a, b])
        parts = message_parts(messages[1], messages[1].content)
        assert sum(len(p["text"]) for p in parts) == len(messages[1].content)
        derived = [p for p in parts if p.get("source_type") == "request_context"]
        assert len(derived) == 1 and derived[0]["text"] == "\nBrief second"
        assert derived[0]["source_path"] == "brief"
    finally:
        request_sources.reset(token)
